<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerPushMT extends Model
{
    protected $table = "customer_pushmt_register";
}
