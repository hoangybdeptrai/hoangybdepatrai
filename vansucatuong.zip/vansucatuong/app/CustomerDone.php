<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerDone extends Model
{
     protected $table = 'customer_sender_done';
}
