<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lich_cua_cac_cung extends Model
{
    protected $table = 'lich_cua_cac_cung';
}
