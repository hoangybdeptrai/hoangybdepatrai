<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerLSSD extends Model
{
    protected $table = 'customer_lichsusudung';
}
