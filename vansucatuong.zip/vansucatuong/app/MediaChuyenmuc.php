<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MediaChuyenmuc extends Model
{
    protected $table = 'cms_media_chuyenmuc';
}
