<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KhachHangCancel extends Model
{
    protected $table = 'customer_cancel';
}
