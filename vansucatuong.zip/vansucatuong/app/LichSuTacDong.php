<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LichSuTacDong extends Model
{
    protected $table = 'lich_su_tac_dong';
	/*
    protected $fillable = [
        'USER_ID'
    ];
	*/
    // protected $primaryKey = 'id'; 
   //  and COMMAND_CODE
    //public $incrementing = false; // Bỏ lỗi hiển thị cùng giá trị MSISDN
}
