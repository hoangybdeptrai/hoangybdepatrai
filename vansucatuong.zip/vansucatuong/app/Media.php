<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Media extends Model
{
    protected $table = 'cms_media';

    public function fileupload()
    {
    	return $this->hasMany('App\Files','id_media');
    }

    public function filemedia()
    {
    	return $this->hasMany('App\TapMedia','id_media');
    }
}

