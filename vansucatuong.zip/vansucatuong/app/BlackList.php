<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BlackList extends Model
{
    protected $table = 'blacklist';
	protected $fillable = [
        'user_id'
    ];
    protected $primaryKey = 'user_id';
    public $incrementing = false;
}
