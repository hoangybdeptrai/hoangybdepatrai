<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WhiteList extends Model
{
    protected $table = 'freelist';
    protected $fillable = [
        'user_id'
    ];
    protected $primaryKey = 'user_id';
    public $incrementing = false;
}
