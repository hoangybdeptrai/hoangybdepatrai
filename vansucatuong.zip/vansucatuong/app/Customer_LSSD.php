<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer_LSSD extends Model
{
    protected $table = 'customer_lichsusudung';
	
}
