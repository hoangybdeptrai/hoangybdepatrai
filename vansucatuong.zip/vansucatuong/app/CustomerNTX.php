<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerNTX extends Model
{
    protected $table = 'customer_ntx';
    protected $primaryKey = 'USER_ID'; 
}
