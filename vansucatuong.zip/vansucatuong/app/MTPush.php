<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MTPush extends Model
{
    protected $table = 'mtsample';
    //protected $table = 'message_reminder';
}
