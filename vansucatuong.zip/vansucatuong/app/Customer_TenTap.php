<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer_TenTap extends Model
{
    protected $table = 'customer_tentap';
	
}
