<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BaivietCtags extends Model
{
    protected $table = 'cms_baiviet_ctags';
}
