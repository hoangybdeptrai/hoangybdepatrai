<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerReport extends Model
{
    protected $table = 'customer_thongke';
}
