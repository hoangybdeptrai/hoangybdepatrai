<?php

use App\Http\Requests;
use App\Post;
namespace App\Http\Controllers;
use App\MTPush;
use App\User;
use App\UserType;
use Illuminate\Support\Facades\Hash;
use Validator;
use Redirect;

use Illuminate\Support\Facades\Auth;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Input;
use PhpParser\Comment;


class UserController extends Controller
{

   function login(){
	  if (Auth::check()) {
		return Redirect::to("/");
	  }
	   return view('admin/layouts/users/login');
	
   }
   
   function logout(){
   	if(Auth::user()->user_type_id == 7){
   		Auth::logout();
	  //echo "User logged out.";
	  return view('admin.layouts.gui_cskh.cskh');

   	}else{
   	  Auth::logout();
	  //echo "User logged out.";
	  return Redirect::to("login");
	}
   }
   
   function postLogin(){
	   $email= Input::get('email');
	   $password = Input::get('password');
	   
	   //echo "sa".Auth::attempt(array('email' => $email, 'password' => $password));die();
	   $var1 = Auth::attempt(array('email' => $email, 'password' => $password),true);
			
 	   if ($var1)
 	   {	
			
		   //echo "Logged in.". Auth::user()->email." ".Auth::user()->id;		
 	       return Redirect::to("admincp");
 	   }else
 		   return Redirect::to("admincp");
 		
   }
   
 
    public function tao_user ()
    {   
		if (!Auth::check()) return \Redirect::to("login");
		if (Auth::user()->user_type_id !=2) return \Redirect::to("/");
		

	   //$messages=array(
	   //  'email.unique' => 'The email has already been taken!!'
	   //);
	   $inputs = Input::all(); 
	   
	   $validator = Validator::make($inputs, User::$rules);
	  
	   if ($validator->passes()){
			$user = new User;
			$user->name = $inputs['name'];
		    $user->password =  Hash::make($inputs['password']);
			$user->email = $inputs['email'];
		    $user->user_type_id =  $inputs['user_type_id'];
			$user->cpname_id = $inputs['cpname_id'];
		   	$user->save();
		 
		  // Auth::login($user);
		   return Redirect::to('danh-muc-user');
	   }
	    //$errors = $validator->messages();
	   //print_r($errors); die();
	   return Redirect::to('tao-user')->withErrors($validator);
     
       
    }

    public function sua_user($id)
    {
		if (!Auth::check()) return \Redirect::to("login");
		// if (Auth::user()->user_type_id !=2) return \Redirect::to("/");
		
		
        $user= User::find($id);
		// if ((Auth::user()->id!=$id)&&($user->user_type_id==2))
		// 	 return \Redirect::to("/");
			
		$user_types = UserType::all();
		
        return view('admin/layouts/users/sua_user', compact('user','user_types'));
    }
	
    public function capnhat_user($id)
    {
		if (!Auth::check()) return \Redirect::to("login");
		// if (Auth::user()->user_type_id !=2) return \Redirect::to("/");
		
		
	   $inputs = Input::all(); 
	   
	   $rules= array(
		'password' => 'required|confirmed|min:3',
		'name'=>'required'	
		);
		
	   $validator = Validator::make($inputs, $rules);
	  
	   if ($validator->passes()){
			$user = User::find($id);
			// if ((Auth::user()->id!=$id)&&($user->user_type_id==2))
			//  return \Redirect::to("/");
			if (Auth::user()->user_type_id == 2){
			$user->name = $inputs['name'];
		    $user->password =  Hash::make($inputs['password']);
			//$user->email = $inputs['email'];
			
		    $user->user_type_id =  $inputs['user_type_id'];
		    $user->save();
		  	}else{
		  	$user->name = $inputs['name'];
		    $user->password =  Hash::make($inputs['password']);
			//$user->email = $inputs['email'];
			
		   
		    $user->save();
		  	}
		  
		 
		   return Redirect::to('danh-muc-user');
	   }
	  //$errors = $validator->messages();
	 // print_r($errors); die();
	   return Redirect::to('user_sua/'.$id)->withErrors($validator);
    }

    public function xoa_user($id)
    {
		if (!Auth::check()) return \Redirect::to("login");
		if (Auth::user()->user_type_id !=2) return \Redirect::to("/");
		

		 
        $user = User::find($id);
		if ($user->user_type_id==2)
			 return \Redirect::to("/");
			
        $user->delete();
        return \Redirect::to('danh-muc-user');
    }
    public function chitiet_user($id)
    {
		if (!Auth::check()) return \Redirect::to("login");
		
		
        $user = User::find($id);
		$user_types = UserType::all();
        return view('admin/layouts/users/chi_tiet_user', compact('user','user_types'));
    }
	
    public function ql_quyen()
    {
		if (!Auth::check()) return \Redirect::to("login");
		if (Auth::user()->user_type_id !=2) return \Redirect::to("/");
		
		$user_type_id = Input::get ('user_type_id');
        $user_type = UserType::find($user_type_id);
		$user_types = UserType::all();
		$user_type_permissions = explode(',',$user_type->permissions);
		
        return view('admin/layouts/users/ql_nhomquyen', compact('user_type_permissions','user_type','user_types'));
    }

    public function ql_nhomquyen($id)
    {
		if (!Auth::check()) return \Redirect::to("login");
		if (Auth::user()->user_type_id !=2) return \Redirect::to("/");
		
		$user_type_id = $id;
        $user_type = UserType::find($user_type_id);
		$user_type->permissions = implode(',',Input::get('user_type_permissions'));
		$user_types = UserType::all();
		$user_type_permissions = Input::get('user_type_permissions');
		$user_type->save();
        return view('admin/layouts/users/ql_nhomquyen', compact('user_type_permissions','user_type','user_types'));
    }	

    //SSO View360
    public function loginProcess(){
    	if (isset($_GET["type"]) && !empty($_GET["type"]) && $_GET["type"] == "CheckUser") { 
		$token = $_GET["token"];
		$url="http://10.211.0.250:8080/SSO/SSOService.svc/user/ValidateTokenUrl?token=" . $token . "<@-@>10020";
		
		$content=file_get_contents($url);  
		$jsonIterator = new \RecursiveIteratorIterator(
		new \RecursiveArrayIterator(json_decode($content, TRUE)),
		\RecursiveIteratorIterator::SELF_FIRST);

		foreach ($jsonIterator as $key => $val) {
			if(!is_array($val)) {
				if($key='Username'){
					$User = $val;
				}
			}
		}
		//kiểm tra quyền
		if($User!=""){
			$urlRole = "http://10.211.0.250:8080/Role/ServiceRole.svc/user/CheckRole?username=" . $User;
			$contentRole=file_get_contents($urlRole); // em check lai code xem co phai la REcursiveIteratorIterator ko ??
			$jsonIteratorRole = new \RecursiveIteratorIterator(
			new \RecursiveArrayIterator(json_decode($contentRole, TRUE)),
			\RecursiveIteratorIterator::SELF_FIRST);
			
			foreach ($jsonIteratorRole as $keyrole => $valrole) {
				if(!is_array($valrole)) {
					if($keyrole='CheckRoleResult'){
						$Role = $valrole;
					}
				}
			}
			//Dùng user $User để đăng nhập vào hệ thống
			//viết code đăng nhập trả về true or false
			$email= $User;
		   	$password = "123456";
		     $guser = User::where('email',$email)->first();
		   	  if (!$guser) {
		   	  	$guser = new User; 
		   	  	$guser->name = $email;
		   	  	$guser->email = $email;
		   	  	$guser->password = Hash::make($password); 
		  		$guser->cpname_id = 0;
		 			
		   	  }
		   	  // DOAN CODE Phia sau nay luon chay trong ca 2 truong hop a` em khong biet :D
		   	  if ($Role== 1){
		   	  		$guser->user_type_id = 7; 
		   	  	}elseif ($Role== 2) {
		   	  		$guser->user_type_id = 7; 
		   	  	}
		   	    $guser->save();
		   	   /// Auth::login($guser) ;// cu TRY thu cai nay xem em tra cho anh co ham login tu dong day
		   	//echo "sa".Auth::attempt(array('email' => $email, 'password' => $password));die();
		   	$var1 = Auth::attempt(array('email' => $email, 'password' => $password),true);

			$ketqua=1;

		}
		else{
			$ketqua=0;
		}
		//trả về giá trị thống báo thành công hoặc không thành công
		print_r ($ketqua);
	}

	
}		
		


	
}
