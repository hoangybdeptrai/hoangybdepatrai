<?php

namespace App\Http\Controllers;
use Datatables;
use Illuminate\Http\Request;
use App\Ctags;

class CtagsController extends Controller
{
//START CATEGORY
    public function index()
    {
        $cate = Ctags::where('loaictags','category')->get();
        $cates = Ctags::where('loaictags','category')->get();
        $catem= Ctags::where('loaictags','category')->get();
        $Ctags=Ctags::get();
        return view('backend.cate.AddCate', compact('cate','cates','catem','Ctags'));
    }
    //LIST
   
    //ADD
    public function addCate(Request $request)
    {
     $cate = new Ctags;
     $cate->tenctags = $request->tenCate;

     if ($request->slug == '') {
        $cate->slug = TaoSlug($request->tenCate);
     }else{
        $cate->slug = $request->slug;
     }
     
     $cate->noidung = $request->noidung;
     $cate->idcha = $request->idcha;
     $cate->loaictags ='category';
     $cate->save();
     return redirect('admincp/category/add-cate')->with('thongbao','Tạo thành công!');
 }
 //GET DATA
 public function viewCate($id){
    $cate = Ctags::where('id',$id)->get();
    echo json_encode($cate);
}
// EDIT
public function editCate(Request $request)
{
    //echo $request->idcate;
    //$cate = new Ctags;
    $cate = Ctags::find($request->idcate);
    $cate->tenctags = $request->tenCate;
    
    if ($request->slug == '') {
        $cate->slug = TaoSlug($request->tenCate);
    }else{
        $cate->slug = $request->slug;
    }

    $cate->noidung = $request->noidung;
    $cate->idcha = $request->idcha;
    $cate->save();
    return redirect('admincp/baiviet/category/add-cate')->with('thongbao','Cập nhật thành công!');
}
//DEL
public function delCate($id){
 $medias = Ctags::find($id);
 $medias->delete();
}

}
