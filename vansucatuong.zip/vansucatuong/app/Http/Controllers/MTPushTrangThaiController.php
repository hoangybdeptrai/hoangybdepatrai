<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\MTPush;
use App\MTActive;
use App\Parameter;
use App\Customer;
use App\CustomerDone;
use App\CustomerNTX;
use App\PhoneNumber;
use App\LichSuTacDong;
use App\Customer_TenTap;
use Datatables;
use DB;
use Active;
use App\UserType;
use PhpParser\Comment;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;

class MTPushTrangThaiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        if (!Auth::check()) return \Redirect::to("login");
        // $u = UserType::find(Auth::user()->user_type_id);
        // $up = explode(',',$u->permissions);
        // if (!in_array('thong_so_trang_thai',$up)) return \Redirect::to("/");
        $mt_push = MTPush::all();

        return view('backend.push_mt.trangthai.index', compact('mt_push'));
    }

    public function getData()
    {
        $stt = 1;
        $mt_do2 = Parameter::select(['id',  'RunAll', 'TotalMt', 'Load',  'Finish']);
        return Datatables::of($mt_do2)
        ->removecolumn('id')
        ->editColumn('RunAll',function($mtdo) {
            if ($mtdo->RunAll == 1) {
                return '<center><p class="btn btn-xs btn-primary">Chạy</p></center>';
            } else {
                return '<center><p class="btn btn-xs btn-danger">Dừng</p></center>';
            }
            
        })
        ->editColumn('TotalMt', '{{$TotalMt}}')
        ->editColumn('Load',function($mtdo) {
            if ($mtdo->Load == 1) {
                return '<center><p class="btn btn-xs btn-primary">Đang Load</p></center>';
            } else {
                return '<center><p class="btn btn-xs btn-danger">Load xong</p></center>';
            }
            
        })
        ->editColumn('Finish',function($mtdo) {
            if ($mtdo->Finish == 1) {
                return '<center><p class="btn btn-xs btn-primary">Đang Push</p></center>';
            } else {
                return '<center><p class="btn btn-xs btn-danger">Push xong</p></center>';
            }
            
        })
            ->addColumn('action', function ($mt_do2) {
                return '<center><a onclick="redirect_active_url(' . "'" . $mt_do2->id . "'" . ')" href="javascript:void(0)" class="btn btn-xs btn-primary ">Bắn MT</a>

                        <a onclick="redirect_cannel_url(' . "'" . $mt_do2->id . "'" . ')" href="javascript:void(0)" class="btn btn-xs btn-danger "></i>Dừng Bắn MT</a></center>
                        
                        ';
                        // <a onclick="redirect_edit_url(' . "'" . $mt_do2->id . "'" . ')" href="javascript:void(0)" class="btn btn-xs btn-primary" id="edit"><i class="glyphicon glyphicon-edit"></i> Sửa</a>

            })

            ->make();   

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.push_mt.trangthai.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $mt_do2 = new Parameter;
        $mt_do2->NUMBER_MESSAGE_PER_DAY = \Request::get('NUMBER_MESSAGE_PER_DAY');
        $mt_do2->NUMBER_CUSTOMER_PER_GROUP = \Request::get('NUMBER_CUSTOMER_PER_GROUP');
        $mt_do2->ACTIVE = \Request::get('ACTIVE');
        $mt_do2->TIME_RUN = \Request::get('TIME_RUN');
        $mt_do2->TIME_RESET_SYSTEM = \Request::get('TIME_RESET_SYSTEM');
        $mt_do2->TIME_GET = \Request::get('TIME_GET');
        $mt_do2->save();
/*
        $mtactive = new MTActive;
        
        $mtactive->Type = \Request::get('ACTIVE');*/

        return \Redirect::to('admincp/parameter');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $mt_do2 = Parameter::find($id);

        return view('backend.push_mt.trangthai.sua', compact('mt_do2'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $mt_do2 = Parameter::find($id);
        $mt_do2->NUMBER_MESSAGE_PER_DAY = \Request::get('NUMBER_MESSAGE_PER_DAY');
        $mt_do2->NUMBER_CUSTOMER_PER_GROUP = \Request::get('NUMBER_CUSTOMER_PER_GROUP');
        $mt_do2->ACTIVE = \Request::get('ACTIVE');
        $mt_do2->TIME_RESET_SYSTEM = \Request::get('TIME_RESET_SYSTEM');
        $mt_do2->TIME_RELOAD_STATUS_CUSTOMER = \Request::get('TIME_RELOAD_STATUS_CUSTOMER');
        $mt_do2->TIME_GET = \Request::get('TIME_GET');
        $mt_do2->TIME_START_SEND = \Request::get('TIME_START_SEND');
        $mt_do2->TIME_STOP_SEND = \Request::get('TIME_STOP_SEND');
        $mt_do2->NUMBER_THREAD = \Request::get('NUMBER_THREAD');
        $mt_do2->user_edit = Auth::user()->email;
        $mt_do2->save();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Cập nhật";
        $user->save();

        return \Redirect::to('admincp/parameter');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $mt_do2 = Parameter::find($id);
        $mt_do2->delete();
        return \Redirect::to('admincp/parameter');
    }

    public function active($id)
    {
        $mt_do2 = Parameter::find($id);
        $mt_do2->RunAll = 1;
        $mt_do2->save();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Bắn";
        $user->save();
        return \Redirect::to('admincp/parameter');
    }

    public function cannel($id)
    {
        $mt_do2 = Parameter::find($id);
        $mt_do2->RunAll = 0;
        //$mt_do2->user_edit = Auth::user()->email;
        $mt_do2->save();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Dừng";
        $user->save();
        return \Redirect::to('admincp/parameter');
    }


    public function active_send($id)
    {
        $mt_do2 = Parameter::find($id);
        $mt_do2->KILL_SEND = 1;
        $mt_do2->save();



        return \Redirect::to('admincp/parameter');
    }

    public function cannel_send($id)
    {
        $mt_do2 = Parameter::find($id);
        $mt_do2->KILL_SEND = 0;
        $mt_do2->save();
        return \Redirect::to('admincp/parameter');
    }

    public function chon_so_luong(Request $request)
    {
        
        $number = Input::get ( 'soluong' );
        $mt_id = Input::get ( 'mt' );

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = 'Thêm số lượng: '.$number.' với MT: '.$mt_id;
        $user->save();

        $number2 = Parameter::find(1);
        $number2->TotalMt += $number;
        $number2->save();

        $mt_push = MTPush::find($mt_id);
        $mt_push->Quantity = $number;
        $mt_push->save();

        return \Redirect::to('admincp/parameter')->withErrors(['Chọn Thành Công', 'The Message']);
    }

    public function upstatus($ten_tap)
    {



       
        set_time_limit(0);
        CustomerNTX::where('ten_tap', $ten_tap)->where('STATUS', '=', 1)
        ->update(['STATUS' =>  0]);

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Reset tập thuê bao: ".$ten_tap;
        $user->save();
        return \Redirect::to('admincp/parameter')->with('status', 'Reset tập thuê bao thành công!!');
    }

    public function reset()
    {



       
        Customer::truncate();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Xóa hàng chờ";
        $user->save();

        return \Redirect::to('admincp/parameter')->with('status', 'Reset hàng chờ thành công!!');
    }

    public function themtapthuebao(){
        $tapthuebao = Input::get ( 'tapthuebao' );
        $soluongtapthuebao = Input::get ( 'soluongtapthuebao' );
        $tap_thuebao = Parameter::find(1);
        $tap_thuebao->tap_thuebao = $tapthuebao.'_'.$soluongtapthuebao;
        $tap_thuebao->save();
        return \Redirect::to('admincp/parameter')->withErrors(['Thêm Thành Công Tập: '.$tapthuebao.' Số Lượng: '.$soluongtapthuebao, 'The Message']);;
    }

    public function them()
    {
        $thuebao = Input::get ( 'thuebaohung' );

        $tb = new PhoneNumber;
        $tb->Msisdn = $thuebao;
        $tb->save();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Thêm thuê bao: ".$thuebao;
        $user->save();

    //     $tb_customer_sender_done = CustomerDone::where('USER_ID', $thuebao);
    //     if(!empty($tb_customer_sender_done)){
        
    //     $tb_customer_sender_done->delete();
    // }
        return \Redirect::to('admincp/parameter')->withErrors(['Thêm Thành Công', 'The Message']);;
    }
}
