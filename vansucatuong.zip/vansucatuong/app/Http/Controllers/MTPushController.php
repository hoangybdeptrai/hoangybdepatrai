<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\MTPush; 
use App\MTActive;
use App\Customer;
use App\CustomerNTX;
use App\KhachHang;
use App\KhachHangCancel;
use App\HungTest;
use App\LichSuTacDong;
use App\PhoneNumber;
use App\Customer_TenTap;
use Datatables;
use DB;
use Active;
use App\UserType;
use PhpParser\Comment;
use Illuminate\Support\Facades\Auth;
use App\Test;

class MTPushController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        if (!Auth::check()) return \Redirect::to("login");
        // $u = UserType::find(Auth::user()->user_type_id);
        // $up = explode(',',$u->permissions);
        // if (!in_array('danh_sach_mt_quang_cao',$up)) return \Redirect::to("/");

        $mts = MTPush::all();
       
        return view('backend.push_mt.mt.index', compact('mts'));
    }

    public function getData()
    {
        $stt = 1;
        $mtdo = MTPush::select(['id',  'Content', 'Status', 'Quantity']);
        return Datatables::of($mtdo)

        ->editColumn('id', '#{{$id}}')
        ->editColumn('Content', '{{$Content}}')
        ->editColumn('Quantity', '{{$Quantity}}')
        ->editColumn('Status',function($mtdo) {
            if ($mtdo->Status == 1) {
                return '<center><p class="btn btn-xs btn-primary">Đã chọn</p></center>';
            } else {
                return '<center><p class="btn btn-xs btn-danger">Chưa chọn</p></center>';
            }
            
        })
/*      ->editColumn('created_at', '{{$created_at}}')
        ->editColumn('updated_at', '{{$updated_at}}')*/
       
      
                
            ->addColumn('kytu', function ($mtdo) {
                $kytu = strlen($mtdo->Content);
                if($kytu > 160){
                return '<a style="color= red">'.strlen($mtdo->Content).'</a>';        
                }else{
                return strlen($mtdo->Content);     
                }

                
            })
         
            ->addColumn('action', function ($mtdo) {
                return '
                            
                        <a onclick="redirect_edit_url(' . "'" . $mtdo->id . "'" . ')" href="javascript:void(0)" class="btn btn-xs btn-primary" id="edit"><i class="glyphicon glyphicon-edit"></i> Sửa</a>

                        <a onclick="remove_mt(' . "'" . $mtdo->id . "'" . ')" href="javascript:void(0)" class="btn btn-xs btn-danger"><i class="fa fa-trash-o"></i> Xóa</a> ';
            })

            ->make();   

           
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.push_mt.mt.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      
        $mtdo = new MTPush;
        $mtdo->id = \Request::get('ID');
        $mtdo->Id_Mt = \Request::get('ID');
        $mtdo->Content = \Request::get('Info');
        // $mtdo->Active = \Request::get('Active');
        $mtdo->save();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Thêm MT ID: ".\Request::get('ID');
        $user->save();


        return \Redirect::to('admincp/mt');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {

        $arr_list = $request->mtpush;

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Chọn MT: ".implode($arr_list, ',');
        $user->save();

        $count = MTPush::all();

        for ($i=1; $i <=count($count) ; $i++) {
           
        $mtactive = MTPush::where('id',$i)->first();
           if (in_array($i, $arr_list))
            {

                $mtactive->Status = 1;
                $mtactive->update();
            }else{

                $mtactive->Status = 0;
                $mtactive->update();
            }
        }

        

        return \Redirect::to('admincp/mt');
        
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $mtdo = MTPush::find($id);
        return view('backend.push_mt.mt.sua', compact('mtdo'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $mtdo = MTPush::find($id);
        $mtdo->id = \Request::get('ID');
        $mtdo->Id_Mt = \Request::get('ID');
        $mtdo->Content = \Request::get('Info');
        //dd($mtdo);
        $mtdo->save();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Sửa MT ID: ".\Request::get('ID');
        $user->save();

        return \Redirect::to('admincp/mt');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $mtdo = MTPush::find($id);
        $mtdo->delete();

        $user = new LichSuTacDong;
        $user->email = Auth::user()->email;
        $user->tac_dong = "Xóa MT ID: ".$id;
        $user->save();

        //return \Redirect::to('admincp/mt');
    }

    public function read(Request $request)
    {
        set_time_limit(0);
        $file = $request->file('txt');
        $file_media = $file->getClientOriginalName();
        $destinationPathMedia = 'readtxt';
        $filename = str_random(8).'_'.$file->getClientOriginalName();

        $file->move($destinationPathMedia, $filename);

        $filename = file_get_contents("./readtxt/$filename", true);

        $arr_sdt = explode(PHP_EOL,$filename);
        // trim bo \r
        if (isset($arr_sdt) && count($arr_sdt) > 0) {
            foreach ($arr_sdt as $key => $value) {
 
                $phone = trim($value);
                // $user = PhoneNumber::where('Msisdn', $phone )->first();
                // if (empty($user)) { 
                  $cus = new PhoneNumber;
                  $cus->Msisdn = $phone;
                  $cus->save();
               		// $user = CustomerNTX::find($phone);
                	// if (empty($user)) { 
                	// $cus = new CustomerNTX;
                	// $cus->USER_ID = $phone;
                	// $cus->ten_tap = $request->input('tentap');
                	// $cus->save();
                
                // }
            }
        }

        // $tap_moi = new Customer_TenTap;
        // $tap_moi->ten_tap = $request->input('tentap');
        // $tap_moi->save();
        

        //return \Redirect::to('admincp/mt/read')->withErrors(['Thêm Thành Công', 'The Message']);


        //echo $filename;
        


        /*$file1 = $request->txt;

        $myfile = fopen("$file1", "r") or die("Unable to open file!");
        while(!feof($myfile)) {
        echo fgets($myfile) . "<br>";
        }
        fclose($myfile);*/
    }

    public function xoacustomer(Request $request){
        $q = \Request::get('thuebao');
        
        if($q[0] == 0){
            $customer = substr_replace($q, '84', 0, 1);
        }else{
            $customer = $q;
        }
        $khachhang = KhachHang::where('USER_ID', $customer)->get();
        $khachhang_cancel = KhachHangCancel::where('USER_ID', $customer)->get();
        if(isset($khachhang))
        foreach ($khachhang as $key => $value) {
            $id = $value->id;
            $kh = KhachHang::find($id);
            $kh->delete();
        }
        if(isset($khachhang_cancel))
        foreach ($khachhang_cancel as $key => $value) {
            $id = $value->id;
            $kh_cancel = KhachHangCancel::find($id);
            $kh_cancel->delete();
        }
        return \Redirect::to('admincp/mt/read')->withErrors(['Xóa thành công số thuê bao: '.$customer, 'The Message']);

    }

}
