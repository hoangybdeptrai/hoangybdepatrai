<?php

namespace App\Http\Controllers;
use App\Http\Requests;
use App\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\Customer;
use Illuminate\Support\Facades\Hash;
use Validator;
use Redirect;
use App\Customer_DK_webs;
use App\Baiviet;
use App\BaivietCtags;
use App\Customer_DK;
use App\Moqueue;
use App\Ctags;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\KhachHang;
use App\Temp_sub_click;
use PhpParser\Comment;


class PageController extends Controller {
    public function header_info() {
        $out = array();
        foreach ($_SERVER as $key => $value) {
            if (substr($key, 0, 5) == "HTTP_") {
                $key = str_replace(" ", "-", ucwords(strtolower(str_replace("_", " ", substr($key, 5)))));
                $out[$key] = $value;
            } else {
                $out[$key] = $value;
            }
        }
        return $out;
    }

        public function fetchIpRequest() {
        try {
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
            return $ip;
        } catch (Exception $e) {
            return "";
        }
    }
    public function dangky($package_code)
    {
          $sodienthoai = $this->getMSISDN();
        
        if($sodienthoai != ''){
            $sodienthoai = '0'.substr_replace($sodienthoai, '', 0, 2);
        }elseif($sodienthoai == '' && !empty(Auth::user()->email)){
            $sodienthoai = '0'.Auth::user()->email;
        }
        $phonenumber = $this->getMSISDN();
        if($phonenumber != ''){
            $phonenumber = $phonenumber;
        }elseif($phonenumber == '' && !empty(Auth::user()->email)){
            $phonenumber = '84'.Auth::user()->email;
        }
        $macuoc = DB::table('service_package')->where('package_code', $package_code)->get();
        $mienphi=DB::table('customer_history')->where('USER_ID',$sodienthoai)->where('COMMAND_CODE',$package_code)->first();
        
        return view('frontend.dangly',compact('macuoc','mienphi'));

    }
    public function getMSISDN() {
        $ip=$this->fetchIpRequest();
        //private
        $patten = "/(^(10)(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$)/";
        $resultMSIDCheck = preg_match($patten, $ip);
        if ($resultMSIDCheck == 0) {
            $patten = "/(^192.168.8[8-9])(\\.([0-9]|1[0-9]|2[0-4]){1}$)/";
            $resultMSIDCheck = preg_match($patten, $ip);
        }
        //Public
        if ($resultMSIDCheck == 0) {
           $patten = "/(^(113|103|101|123|222|183|59|)(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$)/";
            $resultMSIDCheck = preg_match($patten, $ip);
        }
        $msisdn = "";
        if ($resultMSIDCheck == 1) {
            foreach ($this->header_info() as $name => $value) {
                if ($name == "Msisdn") {
                    $msisdn = $value;
                }
            }
        }



       
        return $msisdn;
    }

    

    public function header() {
        $ip=$this->fetchIpRequest();
        //private
        $patten = "/(^(10)(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$)/";
        $resultMSIDCheck = preg_match($patten, $ip);
        if ($resultMSIDCheck == 0) {
            $patten = "/(^192.168.8[8-9])(\\.([0-9]|1[0-9]|2[0-4]){1}$)/";
            $resultMSIDCheck = preg_match($patten, $ip);
        }
        //Public
        if ($resultMSIDCheck == 0) {
           $patten = "/(^(113|103|101|123|222|183|59|)(\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$)/";
            $resultMSIDCheck = preg_match($patten, $ip);
        }
        $msisdn = "";
        if ($resultMSIDCheck == 1) {
            foreach ($this->header_info() as $name => $value) {

                    echo $name.' = '.$value.'</br>';
                
            }
        }

    }
    public function index() {        
	
		$chuyenmuc_cha=Ctags::get();
        $chuyenmuc_baiviet = BaivietCtags::orderBy('updated_at', 'desc')->get();
        $baiviet = Baiviet::orderBy('created_at', 'desc')->get(); 
        $sodienthoai = $this->getMSISDN();
        if($sodienthoai != ''){
            $sodienthoai = '0'.substr_replace($sodienthoai, '', 0, 2);
        }elseif($sodienthoai == '' && !empty(Auth::user()->email)){
            $sodienthoai = '';
        } 

    	return view('frontend.home', compact( 'chuyenmuc_baiviet', 'baiviet', 'chuyenmuc_cha','sodienthoai'));
    }
    public function chuyenmuc($duongdan,$id)
    {
        $chuyenmuc_cha=Ctags::get();
        $chuyenmucbai=Ctags::where('id',$id)->get();
        $chuyenmuc_baiviet = BaivietCtags::where('idctags',$id)->orderBy('created_at', 'desc')->get();

        $baiviet = Baiviet::select('cms_baiviet.anhdaidien','cms_baiviet.id','cms_baiviet.slug','cms_baiviet.noidungngan','cms_baiviet.luotxem','cms_baiviet.created_at','cms_baiviet.tieude')
        ->join('cms_baiviet_ctags','cms_baiviet_ctags.idbaiviet','=','cms_baiviet.id')
        ->where('cms_baiviet_ctags.idctags',$id)
        ->paginate(10);; 
        
        $xemnhieu=Baiviet::orderBy('luotxem','desc')->take(7)->get();
        $sodienthoai = $this->getMSISDN();
        if($sodienthoai != ''){
            $sodienthoai = '0'.substr_replace($sodienthoai, '', 0, 2);
        }elseif($sodienthoai == '' && !empty(Auth::user()->email)){
            $sodienthoai = '';
        } 
        return view('frontend.chuyenmuc', compact( 'chuyenmucbai','chuyenmuc_baiviet', 'baiviet', 'chuyenmuc_cha','sodienthoai','xemnhieu'));
    }
    public function chitiet($slug,$id)
    {
        $chuyenmuc_cha=Ctags::get();
        $chuyenmuc_baiviet = BaivietCtags::orderBy('updated_at', 'desc')->get();
         $baiviet = Baiviet::orderBy('created_at', 'desc')->get(); 
        $sodienthoai = $this->getMSISDN();
        if($sodienthoai != ''){
            $sodienthoai = '0'.substr_replace($sodienthoai, '', 0, 2);
        }elseif($sodienthoai == '' && !empty(Auth::user()->email)){
            $sodienthoai = '';
        } 
        $Baivietid=Baiviet::find($id);
        return view('frontend.chitiet', compact( 'chuyenmuc_baiviet', 'baiviet', 'chuyenmuc_cha','sodienthoai','Baivietid'));

    }
    public function dangkydichvu($package_code){

        $sodienthoai = $this->getMSISDN();
        if(empty($sodienthoai))
            return \Redirect::to("/");
        if($sodienthoai != ''){
            $sodienthoai = '0'.substr_replace($sodienthoai, '', 0, 2);
        }elseif($sodienthoai == '' && !empty(Auth::user()->email)){
            $sodienthoai = '0'.Auth::user()->email;
        }
        $phonenumber = $this->getMSISDN();
        if($phonenumber != ''){
            $phonenumber = $phonenumber;
        }elseif($phonenumber == '' && !empty(Auth::user()->email)){
            $phonenumber = '84'.Auth::user()->email;
        }
        $macuoc = DB::table('service_package')->where('package_code', $package_code)->first();
        $giatien = $macuoc->amount;
        $package = $macuoc->package_code;

        $command_code = $macuoc->register_code;
        $status = 1;
        $cp = Input::get('cp');
        $trans = time();
        $ips = explode(',', isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $_SERVER['REMOTE_ADDR']);
            $total_ips = count($ips);
        $ip = trim($ips[$total_ips - 1]);
        if(!empty($cp)){
                $customer_dk = new Customer_DK;
                if(!empty($phonenumber)){
                    $customer_dk->msisdn = $phonenumber;   
                }
                $customer_dk->trans_id = $trans;
                $customer_dk->CPID = $cp;
                $customer_dk->pkg = $macuoc->package_code;
                $customer_dk->free_circle = 0;
                $customer_dk->price = $macuoc->amount;
                $customer_dk->circle = $macuoc->Duration;
                $customer_dk->channel = '1';
                $customer_dk->link_redirect = 'http://90p.vn/';
                $customer_dk->ip_client = $ip;
                $customer_dk->save();

                if(!empty($phonenumber)){
                    $moq = new Moqueue;
                    $moq->USER_ID = $phonenumber;
                    $moq->SERVICE_ID = '9389';
                    $moq->MOBILE_OPERATOR = 'VMS';
                    $moq->INFO = $command_code;
                    $moq->RECIEVE_DATE = date('Y-m-d H:i:s');
                    $moq->REQUEST_ID = date('YmdHis');
                    $moq->CHANNEL_TYPE = '1';
                  $moq->CPID = $cp;
                   //eturn $moq->CPID;
                   $moq->save();
                //return $cp;
                    $customer= DB::table('customer')->where('USER_ID', $phonenumber)
                    ->where('COMMAND_CODE',$package_code)
                    ->where('CHANNEL_TYPE','1')
                    ->update(['CPID'=>$cp]);
                    $logchanging=DB::table('logcharging'.date('Ym'))
                    ->where('SUBID', $phonenumber)
                    ->where('COMMAND_CODE',$package_code)
                    ->where('CHANNEL_TYPE','1')->update(['CPID'=>$cp]);
                        
                    return redirect()->to('/')->with('status', "Bạn đã đăng ký thành công!");
                   //eturn redirect()->to('/')->with('status', "Bạn đã đăng ký thành công!");
                }
        }else{
            if($package_code = 'DK'){
                $cp = 109;
            }elseif($package_code = 'GM'){
                $cp = 110;
            }elseif($package_code = 'TCV'){
                $cp = 111;
            }
                //$customer_dk = new Customer_DK;
                // $customer_dk->msisdn = $phonenumber;
               // $customer_dk->CPID = $cp;
               // $customer_dk->trans_id = $trans;
               // $customer_dk->package_code = $package_code;
               // $customer_dk->save();
                $Customer_DK_webs=new Customer_DK_webs;
                $Customer_DK_webs->USER_ID=$phonenumber;
                $Customer_DK_webs->package_code=$package;
                $Customer_DK_webs->save();
        }
        try {
            
            $returnUrl =  'http://90p.vn/'; 
            $backUrl = $returnUrl;
            
           
            $mes01=$giatien."đ Miễn phí 1 ngày";
            $textInfomation=$this->encodeDecimal($mes01)."||".$this->encodeDecimal("<br/><br/>");
           $mienphi=DB::table('customer_cancel')->where('USER_ID',$phonenumber)
           ->where('COMMAND_CODE',$package)->get();
           if(isset($mienphi[0])) $mp=0;else $mp=1;
            $link = "$trans&$command_code&$package&http://vansucattuong.com.vn/";
            $key = "F6ZW2IM2JVP8edbo";
            $paramsLinkEncode = base64_encode($this->aes128_ecb_encrypt($key, $link, ""));
            $note="";
            //return $paramsLinkEncode;
            //$url ="http://free.mobifone.vn/confirm?sp=9389&link=".$paramsLinkEncode;
            $url ="http://free.mobifone.vn/confirm?sp=098&link=".$paramsLinkEncode;
            
            return redirect()->away($url);
        } catch(Exception $e) {
            echo $e->getMessage();
            exit();
        }

        
    }

        public function huydichvu($package_code){
        $sodienthoai = $this->getMSISDN();
        if($sodienthoai != ''){
            $sodienthoai = '0'.substr_replace($sodienthoai, '', 0, 2);
        }elseif($sodienthoai == '' && !empty(Auth::user()->email)){
            $sodienthoai = '0'.Auth::user()->email;
        }
        $macuoc = DB::table('service_package')->where('package_code', $package_code)->first();
        $giatien = $macuoc->amount;
        $package = $macuoc->package_code;
        $command_code = $macuoc->cancelcode;
        //$command_code = substr_replace($command_code, '_', 3, 0);
        $status = 0;
        try {
            
            $returnUrl =  'http://vansucattuong.com.vn/'; 
            $backUrl = $returnUrl;
            $trans = time();
            
            $mes01=$giatien."đ Miễn phí 1 ngày";
            $textInfomation=$this->encodeDecimal($mes01)."||".$this->encodeDecimal("<br/><br/>");
            
            $link = "$trans&$command_code&$package&$backUrl";
            $key = "F6ZW2IM2JVP8edbo";

            $paramsLinkEncode = base64_encode($this->aes128_ecb_encrypt($key, $link, ""));
            $note="";
            
            //$url ="http://free.mobifone.vn/confirm?sp=9389&link=".$paramsLinkEncode;
            $url ="http://free.mobifone.vn/confirm?sp=098&link=".$paramsLinkEncode;
            return redirect()->away($url);
        } catch(Exception $e) {
            echo $e->getMessage();
            exit();
        }
        //return back();
    }
   
    

     private function aes128_ecb_encrypt($key, $data, $iv) {
        if (16 !== strlen($key))
            $key = hash('MD5', $key, true);
        if (16 !== strlen($iv))
            $iv = hash('MD5', $iv, true);
        $padding = 16 - (strlen($data) % 16);
        $data .= str_repeat(chr($padding), $padding);
        return mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $data, MCRYPT_MODE_ECB, $iv);
    }

    private function aes256_ecb_decrypt($key, $data, $iv) {
        if (32 !== strlen($key))
            $key = hash('SHA256', $key, true);
        if (16 !== strlen($iv))
            $iv = hash('MD5', $iv, true);
        $data = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $data, MCRYPT_MODE_ECB, $iv);
        $padding = ord($data[strlen($data) - 1]);
        return substr($data, 0, -$padding);
    }

    private function encodeDecimal($str) {

        $arrEncode = array(
            "&#97;", "&#225;", "&#224;", "&#7843;", "&#227;", "&#7841;",
            "&#259;", "&#7855;", "&#7857;", "&#7859;", "&#7861;", "&#7863;",
            "&#226;", "&#7845;", "&#7847;", "&#7849;", "&#7851;", "&#7853;",
            "&#101;", "&#233;", "&#232;", "&#7867;", "&#7869;", "&#7865;",
            "&#234;", "&#7871;", "&#7873;", "&#7875;", "&#7877;", "&#7879;",
            "&#105;", "&#237;", "&#236;", "&#7881;", "&#297;", "&#7883;",
            "&#111;", "&#243;", "&#242;", "&#7887;", "&#245;", "&#7885;",
            "&#244;", "&#7889;", "&#7891;", "&#7893;", "&#7895;", "&#7897;",
            "&#417;", "&#7899;", "&#7901;", "&#7903;", "&#7905;", "&#7907;",
            "&#117;", "&#250;", "&#249;", "&#7911;", "&#361;", "&#7909;",
            "&#432;", "&#7913;", "&#7915;", "&#7917;", "&#7919;", "&#7921;",
            "&#121;", "&#253;", "&#7923;", "&#7927;", "&#7929;", "&#7925;",
            "&#273;",
            "&#65;", "&#193;", "&#192;", "&#7842;", "&#195;", "&#7840;",
            "&#258;", "&#7854;", "&#7856;", "&#7858;", "&#7860;", "&#7862;",
            "&#194;", "&#7844;", "&#7846;", "&#7848;", "&#7850;", "&#7852;",
            "&#69;", "&#201;", "&#200;", "&#7866;", "&#7868;", "&#7864;",
            "&#202;", "&#7870;", "&#7872;", "&#7874;", "&#7876;", "&#7878;",
            "&#73;", "&#205;", "&#204;", "&#7880;", "&#296;", "&#7882;",
            "&#79;", "&#211;", "&#210;", "&#7886;", "&#213;", "&#7884;",
            "&#212;", "&#7888;", "&#7890;", "&#7892;", "&#7894;", "&#7896;",
            "&#416;", "&#7898;", "&#7900;", "&#7902;", "&#7904;", "&#7906;",
            "&#85;", "&#218;", "&#217;", "&#7910;", "&#360;", "&#7908;",
            "&#431;", "&#7912;", "&#7914;", "&#7916;", "&#7918;", "&#7920;",
            "&#89;", "&#221;", "&#7922;", "&#7926;", "&#7928;", "&#7924;",
            "&#272;",
        );
        $arrDecode = array(
            "a", "á", "à", "ả", "ã", "ạ",
            "ă", "ắ", "ằ", "ẳ", "ẵ", "ặ",
            "â", "ấ", "ầ", "ẩ", "ẫ", "ậ",
            "e", "é", "è", "ẻ", "ẽ", "ẹ",
            "ê", "ế", "ề", "ể", "ễ", "ệ",
            "i", "í", "ì", "ỉ", "ĩ", "ị",
            "o", "ó", "ò", "ỏ", "õ", "ọ",
            "ô", "ố", "ồ", "ổ", "ỗ", "ộ",
            "ơ", "ớ", "ờ", "ở", "ỡ", "ợ",
            "u", "ú", "ù", "ủ", "ũ", "ụ",
            "ư", "ứ", "ừ", "ử", "ữ", "ự",
            "y", "ý", 'ỳ', "ỷ", "ỹ", "ỵ",
            "đ",
            "A", "Á", "À", "Ả", "Ã", "Ạ",
            "Ă", 'Ắ', "Ằ", "Ẳ", "Ẵ", "Ặ",
            "Â", "Ấ", "Ầ", "Ẩ", "Ẫ", "Ậ",
            "E", "É", "È", "Ẻ", "Ẽ", "Ẹ",
            "Ê", "Ế", "Ề", "Ể", "Ễ", "Ệ",
            "I", "Í", "Ì", "Ỉ", "Ĩ", "Ị",
            "O", "Ó", "Ò", "Ỏ", "Õ", "Ọ",
            "Ô", "Ố", "Ồ", "Ổ", "Ỗ", "Ộ",
            "Ơ", "Ớ", "Ờ", "Ở", "Ỡ", "Ợ",
            "U", "Ú", "Ù", "Ủ", "Ũ", "Ụ",
            "Ư", "Ứ", "Ừ", "Ử", "Ữ", "Ự",
            "Y", "Ý", "Ỳ", "Ỷ", "Ỹ", "Ỵ",
            "Đ",
        );
        $textEncode = str_replace($arrDecode, $arrEncode, $str);
        return str_replace("&#", "##", $textEncode);
    }

    public function dangnhap(){

        $sodt = Input::get('email');

        if($sodt[0] == 0){
            $email = substr_replace($sodt, '', 0, 1);
        }else{
            $email = $sodt;
        }

        $password = Input::get('password');
        $nguoidung = User::where('email', $email)->first();

        if(!empty($nguoidung)){

            $matkhau_moi = DB::table('customer')->where('USER_ID', $email)->first();

            if(!empty($matkhau_moi)){

                if($password == $matkhau_moi->PASSWORD){

                $nguoidung->password = Hash::make($password);
                $nguoidung->save();

                $var1 = Auth::attempt(array('email' => $email, 'password' => $password),true);

                    if ($var1){
                        return back()->with('status', 'Đăng nhập thành công');
                    }else{
                       return back()->with('status', 'Đăng nhập không thành công.  Sai số điện thoại hoặc mật khẩu.');
                        }
                }else{
                    return back()->with('status', 'Đăng nhập không thành công.  Sai mật khẩu.');
            }
            }else{
                return back()->with('status', 'Đăng nhập không thành công. Sai số điện thoại hoặc bạn chưa đăng ký.');
            }      

        }else{

            $matkhau_moi = DB::table('customer')->where('USER_ID', $email)->first();

            if(!empty($matkhau_moi)){

                if($matkhau_moi->PASSWORD == $password){

                    $nguoidung_moi = new User;
                    $nguoidung_moi->email = $email;
                    $nguoidung_moi->name = "user_web";
                    $nguoidung_moi->password = Hash::make($password);
                    $nguoidung_moi->user_type_id = 23;
                    $nguoidung_moi->save();
            
                    $var1 = Auth::attempt(array('email' => $email, 'password' => $password),true);

                        if ($var1){
                            return back()->with('status', 'Đăng nhập thành công.');
                        }else{
                            return back()->with('status', 'Đăng nhập không thành công. Sai số điện thoại hoặc mật khẩu');
                        }
                }else{

                    return back()->with('status', 'Đăng nhập không thành công. Sai mật khẩu.');
                }
            }else{
                    return back()->with('status', 'Đăng nhập không thành công. Sai số điện thoại hoặc bạn chưa đăng ký.');
            }


        }

    }

    

}