<?php

use App\Http\Requests;
use App\Post;
namespace App\Http\Controllers;

use App\UserTypes;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use App\KhachHang;  
use App\KhachHangCancel; 
use App\GoiCuoc; 
use App\Cpname; 
use App\Cp; 
use App\CustomerHistory; 
use App\CustomerLSSD; 
use App\UserType;
use App\WhiteList;  
use App\MTMau;  
use App\Baiviet; 
use App\Ctags;
Use App\Blacklist;
use Illuminate\Support\Facades\Input;
use PhpParser\Comment;
use App\User; 
use APP\Moqueue;
use Illuminate\Support\Facades\Auth;

class CSKHController extends Controller
{
	public $SUCCESS = 'Successful';  // should be Successful for tgphim
	public $APP_CSKH = 'CSKH'; // should be CSKH for tgphim
	public $CHANNEL_FIELD = 'CHANNEL_TYPE';
     public static $api='http://90p.vn//VmsAPI.asmx/';
     public static $packageCode=['','TCV','GM','DK'];
	public function tao_GoiCuoc (Request $request)
    {   
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
        $goi_cuoc = new GoiCuoc;
        $goi_cuoc->register_code = \Request::get('register_code');
		$goi_cuoc->package_code = \Request::get('package_code');
		$goi_cuoc->amount = \Request::get('amount');
		$goi_cuoc->Duration = \Request::get('Duration');
		$goi_cuoc->Status = \Request::get('Status');
		$goi_cuoc->cancelcode = \Request::get('cancelcode');
		$goi_cuoc->FreeDuration = \Request::get('FreeDuration');
		$goi_cuoc->DurationName = \Request::get('DurationName');
		$goi_cuoc->FreePrice = \Request::get('FreePrice');
		$goi_cuoc->FreeScore = \Request::get('FreeScore');
		$goi_cuoc->auto_renew = \Request::get('auto_renew');
		$goi_cuoc->service_name = \Request::get('service_name');
		$goi_cuoc->package_name = \Request::get('package_name');
		$goi_cuoc->all_cancel_code = \Request::get('all_cancel_code');
		$goi_cuoc->cpId = \Request::get('cpId');
		$goi_cuoc->package_name_code = \Request::get('package_name_code');
		$goi_cuoc->service_code = \Request::get('service_code');
		$goi_cuoc->amount_string = \Request::get('amount_string');        

        $goi_cuoc->save();
        return \Redirect::to('admincp/cac-goi-cuoc');
    }
    public function Blacklist(){
        $Blacklist=Blacklist::get();
        
    }
    public function xoa_WL($id)
    {
        $bl=WhiteList::where('user_id',$id)->delete();;;

        return \Redirect::to("admincp/white-list");
    }
    public function xoa_BL($id)
    {
         $bl=Blacklist::where('user_id',$id)->delete();;;

        return \Redirect::to("admincp/black-list");
    }
    public function them_WL (Request $request)
    {   
        if (!Auth::check()) return \Redirect::to("admincp/login");
    
        $stt = 1;
        
         $q = Input::get ( 'wl_them' ); 
        $white_list = WhiteList::find($q);
        if(!empty($white_list))
            return back()->with('status', 'WhiteList Đã Tồn Tại!');
        else
        $c = new WhiteList;
        $c->user_id = $q;
        $c->save();
   
            return back()->with('status', 'Thêm WhiteList Thành Công!');

        
    }
    public function them_BL (Request $request)
    {   
        if (!Auth::check()) return \Redirect::to("admincp/login");
    
        $stt = 1;
        
         $q = Input::get ( 'Bl_them' ); 
        $white_list = Blacklist::find($q);
        if(!empty($white_list))
            return back()->with('status', 'BlackList Đã Tồn Tại!');
        else
        $c = new Blacklist;
        $c->user_id = $q;
        $c->save();
   
            return back()->with('status', 'Thêm BlackList Thành Công!');

        
    }
    public function thong_ke_tong()
    {   
    
        if (!Auth::check()) return \Redirect::to("login");
        
    
        $stt = 1;
        $doitac = Input::get ( 'doitac' );
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        
        $fast = Input::get ( 'fast' );
        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

        //$ranges = $this->spanquery($start,$end);
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;

        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));

            $endh = (date('Y-m-d 04:00:00', strtotime($runtime)));
            $month_tuan = (date("m",strtotime($runtime.'-6 days')));

            try {
            
            //SMS
            $sms_1 = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as sms_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON', 'REG')->where('ERROR','0')->where($this->CHANNEL_FIELD,'SMS')->get();
            $sms_2 = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as sms_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','=','RENEW')->where('ERROR','0')->where($this->CHANNEL_FIELD,'SMS')->get();              
            //WEB
            $web_1 = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as web_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON', 'REG')->where('ERROR','0')->where($this->CHANNEL_FIELD,'WEB')->get();
            $web_2 = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as web_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','=','RENEW')->where('ERROR','0')->where($this->CHANNEL_FIELD,'WEB')->get();
            //WAP
            $wap_1 = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as wap_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON', 'REG')->where('ERROR','0')->where($this->CHANNEL_FIELD,'WAP')->get();
            $wap_2 = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as wap_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','=','RENEW')->where('ERROR','0')->where($this->CHANNEL_FIELD,'WAP')->get();

            // KHAC
            $khac = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as khac_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','!=','UNREG')->where('ERROR','0')->where($this->CHANNEL_FIELD, '<>', 'SMS')->where($this->CHANNEL_FIELD, '<>', 'WEB')->where($this->CHANNEL_FIELD, '<>', 'WAP')->get();

            // DK HUY 
            $dk = DB::table('logcharging'.$year.$month)->select(DB::raw('count(id) as dk_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON', 'REG')->where('ERROR','0')->get();

            $huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(id) as huy_ngay'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','=','UNREG')->where('ERROR_DESC',$this->SUCCESS)->get();

            $articles []= array(date('d-m-Y',strtotime($runtime)),
                $this->pa($sms_1[0]->sms_ngay),
                $this->pa($sms_2[0]->sms_ngay),
                $this->pa($web_1[0]->web_ngay),
                $this->pa($web_2[0]->web_ngay),         
                $this->pa($wap_1[0]->wap_ngay),
                $this->pa($wap_2[0]->wap_ngay), 
                $this->pa($khac[0]->khac_ngay), 
                $this->pa($dk[0]->dk_ngay), 
                $this->pa($huy[0]->huy_ngay),
                );
            
            $sumup[0]+= $sms_1[0]->sms_ngay;
            $sumup[1]+= $sms_2[0]->sms_ngay;
            $sumup[2]+= $web_1[0]->web_ngay;
            $sumup[3]+= $web_2[0]->web_ngay;
            $sumup[4]+= $wap_1[0]->wap_ngay;
            $sumup[5]+= $wap_2[0]->wap_ngay;
            $sumup[10]+= $khac[0]->khac_ngay;
            $sumup[11]=($sumup[0]+$sumup[1]+$sumup[2]+$sumup[3]+$sumup[4]+$sumup[5]+$sumup[10]);
            $sumup[12]+= $dk[0]->dk_ngay;
            $sumup[13]+= $huy[0]->huy_ngay;
            
            } catch (\Illuminate\Database\QueryException $e) {
            }       
            
            $runtime = $tomorrowdate;
        }


        $articles = array_reverse($articles);
        $cpname = Cpname::all();    
        
        
        return view('admin/bao_cao/thong_ke_tong',compact('articles','sumup','fast', 'cpname', 'start', 'end'));
    }
    public function thong_ke_doanh_thu_goi()
    {   
    
        if (!Auth::check()) return \Redirect::to("login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        
        $fast = Input::get ( 'fast' );
        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

        //$ranges = $this->spanquery($start,$end);
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            
            
            try {
            
            // E
            $HD = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','<>','UNREG')->where('COMMAND_CODE','HD')->where('ERROR','0')->get();
            $TV=DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','<>','UNREG')->where('COMMAND_CODE','TV')->where('ERROR','0')->get();
            $PT=DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','<>','UNREG')->where('COMMAND_CODE','PT')->where('ERROR','0')->get();
            $VIP=DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','<>','UNREG')->where('COMMAND_CODE','VIP')->where('ERROR','0')->get();

            
            
            $articles []= array(date('Y-m-d',strtotime($runtime))
                ,$this->pa($HD[0]->c)
                ,$this->pa($TV[0]->c)
                ,$this->pa($PT[0]->c)
                ,$this->pa($VIP[0]->c)
                );
            
            $sumup[0]+= $HD[0]->c;
            $sumup[1]+= $TV[0]->c;
            $sumup[2]+= $PT[0]->c;
            $sumup[3]+= $VIP[0]->c;
            
            

            
            } catch (\Illuminate\Database\QueryException $e) {
            }       
            
            $runtime = $tomorrowdate;
        }
        $articles = array_reverse($articles);
        
        
       
        return view('admin/bao_cao/thong_ke_doanh_thu_goi',compact('articles','sumup','fast', 'start', 'end'));
    }


        public function thong_ke_so_thue_bao()
    {   
    
        if (!Auth::check()) return \Redirect::to("admincp/login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $gc_name = Input::get ( 'goicuoc' );
        $fast = Input::get ( 'fast' );

        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

        //$ranges = $this->spanquery($start,$end);
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;
        $code = 1;
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            
            
            
            try {
            $CAUVANG = DB::table('logcharging'.$year.$month)->select(DB::raw('count(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('PRICE','!=','0')
            ->where('COMMAND_CODE','TCV')
            ->where('ERROR_DESC',$this->SUCCESS)
            ->get();
            $GIAIMATRANDAU=DB::table('logcharging'.$year.$month)->select(DB::raw('count(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('COMMAND_CODE','GM')
              ->where('PRICE','!=','0')
            ->where('ERROR_DESC',$this->SUCCESS)
            ->get();
            
            $TINTUCTONGHOP=DB::table('logcharging'.$year.$month)->select(DB::raw('count(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('COMMAND_CODE','DK')
              ->where('PRICE','!=','0')
            ->where('ERROR_DESC',$this->SUCCESS)
            ->get();
            
            $cc = array("ngay"=>date('d/m/Y',strtotime($runtime)),  
               
                'CAUVANG'=>$this->pa($CAUVANG[0]->c),
                'GIAIMATRANDAU'=>$this->pa($GIAIMATRANDAU[0]->c),
                'TINTUCTONGHOP'=>$this->pa($TINTUCTONGHOP[0]->c),
                
                );

            $articles []= $cc;
            $sumup[0]+=$cc['CAUVANG'];
            $sumup[1]+=$cc['GIAIMATRANDAU'];
            $sumup[2]+=$cc['TINTUCTONGHOP'];
            $sumup[3]+=$cc['CAUVANG']+$cc['GIAIMATRANDAU']+$cc['TINTUCTONGHOP'];
            
            

            } catch (\Illuminate\Database\QueryException $e) {
            }       
        
            $runtime = $tomorrowdate;

        }


        $articles = array_reverse($articles);
        $goicuoc = Cp::all();  
        //print_r($articles);die();
        
       
        return view('backend/bao_cao/thong_ke_thue_bao_so_dang_ky',compact('articles','sumup','fast'));
    }
    public function sua_GoiCuoc($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
        $goi_cuoc = GoiCuoc::find($id);
        return view('backend/goicuoc/sua_gioi_cuoc', compact('goi_cuoc'));
    }
    
    public function capnhat_GoiCuoc($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	   
        $goi_cuoc = GoiCuoc::find($id);
        $goi_cuoc->register_code = \Request::get('register_code');
		$goi_cuoc->package_code = \Request::get('package_code');
		$goi_cuoc->amount = \Request::get('amount');
		$goi_cuoc->Duration = \Request::get('Duration');
		$goi_cuoc->Status = \Request::get('Status');
		$goi_cuoc->cancelcode = \Request::get('cancelcode');
		$goi_cuoc->FreeDuration = \Request::get('FreeDuration');
		$goi_cuoc->DurationName = \Request::get('DurationName');
		$goi_cuoc->FreePrice = \Request::get('FreePrice');
		$goi_cuoc->FreeScore = \Request::get('FreeScore');
		$goi_cuoc->auto_renew = \Request::get('auto_renew');
		$goi_cuoc->service_name = \Request::get('service_name');
		$goi_cuoc->package_name = \Request::get('package_name');
		$goi_cuoc->all_cancel_code = \Request::get('all_cancel_code');
		$goi_cuoc->cpId = \Request::get('cpId');
		$goi_cuoc->package_name_code = \Request::get('package_name_code');
		$goi_cuoc->service_code = \Request::get('service_code');
		$goi_cuoc->amount_string = \Request::get('amount_string');
        $goi_cuoc->save();
        return \Redirect::to('admincp/cac-goi-cuoc');
    }

    public function xoa_GoiCuoc($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
        $goi_cuoc = GoiCuoc::find($id);
        $goi_cuoc->delete();
        return \Redirect::to('admincp/cac-goi-cuoc');
    }
    public function chitiet_GoiCuoc($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
        $goi_cuoc = GoiCuoc::find($id);
        return view('backend/goi_cuoc/chi_tiet_goi_cuoc', compact('goi_cuoc'));
    }
    public function timkiem_ThueBao(Request $request)
 {
    if (!Auth::check()) return \Redirect::to("admincp/login");
    if(Auth::user()->user_type_id == 100){
        Auth::logout();return \Redirect::to("admincp/login");
    }
        // $stt = 1;
        // $q = Input::get ( 'tim_kiem' );
        // $b = KhachHang::where('USER_ID','LIKE','%'.$q.'%')->get();
        // if(count($b) <= 0){
        //  $b = KhachHangCancel::where('USER_ID','LIKE','%'.$q.'%')->get();
        // }
        // if(count($b) > 0)
        //     return view('admin/layouts/thue_bao/thue_bao', compact('stt','q'))->withDetails($b);
        // else

        //     return view ('admin/layouts/thue_bao/thue_bao')->withErrors(['Không tìm thấy dữ liệu!', 'The Message']);
    
    $stt = 1;
        // $q = Input::get ( 'tim_kiem' );
    $q = \Request::get('keyword');
    if($q[0] == 0){
        $phone_number = substr_replace($q, '84', 0, 1);
    }else{
        $phone_number = $q;

    }
     if (Auth::check()) $name= Auth::user()->name; 
     if($name=='Khang')
     {

         $b = CustomerHistory::where('USER_ID', $phone_number)->where('SERVICE_NAME','KIDSAFE')->first();
        $customer = KhachHang::where('USER_ID', $phone_number)->where('SERVICE_NAME','KIDSAFE')->get();

        $customer_cancel = KhachHangCancel::where('USER_ID', $phone_number)->where('SERVICE_NAME','KIDSAFE')->get();

        // Lưu số thuê bao search
        $user_id = Auth::user();
        $user_id->USER_ID = $phone_number;
        $user_id->save();
        $phone = Auth::user()->USER_ID;
        if (Auth::check()) $name= Auth::user()->name; 
        

        if(count($b) > 0)
            return view('backend/thue_bao/tracuuthuebao', compact('stt','q', 'b', 'phone', 'customer', 'customer_cancel'));

                // return redirect('chi-tiet-thue-bao/'.$b->USER_ID);
        else

            // return view ('admin/layouts/thue_bao/thue_bao')->withErrors(['Không tìm thấy dữ liệu!', 'The Message']);
        return view('backend/thue_bao/tracuuthuebao', compact('stt','q', 'phone'));
     }
    $b = CustomerHistory::where('USER_ID', $phone_number)->first();
    $customer = KhachHang::where('USER_ID', $phone_number)->get();

    $customer_cancel = KhachHangCancel::where('USER_ID', $phone_number)->get();

        // Lưu số thuê bao search
    $user_id = Auth::user();
    $user_id->USER_ID = $phone_number;
    $user_id->save();
    $phone = Auth::user()->USER_ID;
        if (Auth::check()) $name= Auth::user()->name; 
        
     //return count($customer);
    if(count($customer) > 0)

        return view('backend/thue_bao/tracuuthuebao', compact('stt','q', 'b', 'phone', 'customer', 'customer_cancel'));

            // return redirect('chi-tiet-thue-bao/'.$b->USER_ID);
    else

            // return view ('admin/layouts/thue_bao/thue_bao')->withErrors(['Không tìm thấy dữ liệu!', 'The Message']);
        return view('backend/thue_bao/tracuuthuebao', compact('stt','q', 'phone'));

}
    public function chitietThueBao($MSISDN)
    {   
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
        $stt = 1;
		$tab = "thong_tin_chung";
        $article = KhachHang::where('USER_ID',$MSISDN)->first();
		if (!$article) {
			$article =  DB::table('customer_cancel')->where('USER_ID',$MSISDN)->first();
		}		
        $cus = CustomerHistory::where('USER_ID',$MSISDN)->get();
		if (count($cus)==0) {
			$cus =  DB::table('customer_cancel')->where('USER_ID',$MSISDN)->get();
		}
       	$hung = KhachHang::where('USER_ID',$MSISDN)->get();
        $goi_cuoc = GoiCuoc::all();
        $type1 = Input::get ( 'type' );
        $custo = KhachHang::where('USER_ID', $MSISDN)->get();
        
        if (count($custo) > 1) {
        	$customer = $custo;
        }else{
        	$customer = '';
        }
        return view('backend/thue_bao/chi_tiet_thue_bao', compact('tab', 'article','cus', 'stt', 'goi_cuoc','type1', 'hung' , 'customer'));
    }
    public function timkiemLSTBTT()
    {
        $stt  = 1;
	
		$MSISDN = Input::get ( 'so_thuebao');
      
		if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
			$end= date("Y-m-d")." 23:59:59";
			if (empty(Input::get ( 'time_bat_dau' )))
			  $start = date('Y-m-d H:i:s', strtotime('-7 days'));
			else
			  $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");  			
		} else {
				
			$start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
			$end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
		}
		
	
			$query = DB::table('customer_history')->where('USER_ID',$MSISDN)->where('DATECREATE', '>=', $start)->where('DATECREATE', '<=', 
				$end)->where('CPID','<>',"");
			
			
			$articles = $query->get();
				
	
        
          return view('backend/thue_bao/thue_bao_truyen_thong', compact('stt'))->withDetails($articles);
    }
    public function sua_Cpname($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
		
        $cpname = Cpname::find($id);
        return view('backend/truyen_thong/sua_cpname', compact('cpname'));
    }
    public function capnhat_Cpname($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
		
        $cpname = Cpname::find($id);
		$cpname->CP_NAME = \Request::get('CP_NAME');
        $cpname->save();
        return \Redirect::to('admincp/danh-muc-cpname');
    }
    
    public function xoa_Cpname($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
		
        $cpname = Cpname::find($id);
        $cpname->delete();
        return \Redirect::to('admincp/danh-muc-cpname');
    }
    public function chitiet_Cpname($id)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
		
        $cpname = Cpname::find($id);
        return view('backend/truyen_thong/chi_tiet_cpname', compact('cpname'));
    }
    public function tao_cp ($linksms)
    {   
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
		$goi_cuoc = \Request::get('goi_cuoc');
        $cp = new Cp;
        $cp->NAME_ID = \Request::get('NAME_ID');    
		if ($linksms==1) {
			$cp->LINKWAP = "dang-ky-dich-vu/".$goi_cuoc.'?cp=';
            $cp->CHANNEL_TYPE = "WAP";
		} else
		if ($linksms==2)
		{	$cp->CHANNEL_TYPE = "SMS";
			$cp->REGISTER_CODE = \Request::get('REGISTER_CODE');
		}
		$cp->ACTIVE = 1;
        $cp->TIMESUBMIT = 60;
        $cp->PARENT_ID = 0;
        $cp->save();
	   
		if ($linksms==1) 
        return \Redirect::to('admincp/marketing-link');
		else if ($linksms==2) return \Redirect::to('admincp/marketing-sms');
    }
    public function tao_Cpname (Request $request)
    {   

        $cpname = new Cpname;
        $cpname->CP_NAME = \Request::get('CP_NAME');    

        $cpname->save();
        return \Redirect::to('admincp/danh-muc-cpname');
    }
  public function xoa_cp($id,$linksms)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
	
        $cp = Cp::find($id);
        $cp->delete();
		
		
		if ($linksms==1) 
        return \Redirect::to('admincp/marketing-link');
		else if ($linksms==2) return \Redirect::to('admincp/marketing-sms');
    }
    public function chitiet_cp($id,$linksms)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
	
        $cp= Cp::join('cpname', 'cpname.id', '=', 'cp.NAME_ID')->where('cp.id',"=",$id)
	  ->select('cp.*', 'cpname.CP_NAME')->first();	
	  
		
		if ($linksms==1) $lstr = 'link'; else if ($linksms==2) $lstr =  'SMS';
        return view('backend/truyen_thong/chi_tiet_cp', compact('cp','linksms','lstr'));
    }
    
    
    public function sua_MT($id,$mtdk)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
        $mt = MTMau::find($id);
        $goi_cuoc = GoiCuoc::all();
        return view('admin/layouts/danh_sach_MT/sua_mt', compact('mt','mtdk', 'goi_cuoc'));
    }
    public function xoa_MT($id,$mtdk)
    {
        $mt=MTMau::destroy($id);
        return \Redirect::to('admincp/mt-danh-sach');
    }
    public function capnhat_MT($id,$mtdk)
    {
		if (!Auth::check()) return \Redirect::to("admincp/login");
	
	
        $mt = MTMau::find($id);
        $mt->Type = \Request::get('Type');
        $mt->Info = \Request::get('Info');
        $mt->Description = \Request::get('Description');
        $mt->save();
		if ($mtdk==0)
        return \Redirect::to('admincp/mt-danh-sach');
		else return \Redirect::to('admincp/mt-dinh-ky');
    }
    public function tao_MT (Request $request)
    {   
		if (!Auth::check()) return \Redirect::to("admincp/login");
	

        $mt_mau = new MTMau;     
        $mt_mau->Type = \Request::get('Type');
		$mt_mau->MTDK = 0;
        $mt_mau->Info = \Request::get('Info');
        $mt_mau->Description = \Request::get('Description');
        $mt_mau->save();
        return \Redirect::to('admincp/mt-danh-sach');
    }
	
	public function tao_MTDK(Request $request)
    {   

        $mt_mau = new MTMau;     
        $mt_mau->Type = \Request::get('Type');
		$mt_mau->MTDK = 1;
        $mt_mau->Info = \Request::get('Info');
        $mt_mau->Description = \Request::get('Description');
        $mt_mau->save();
        return \Redirect::to('admincp/mt-dinh-ky');
    }

    public function thong_ke_doanh_thu()
    {   
	
	   if (!Auth::check()) return \Redirect::to("admincp/login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $gc_name = Input::get ( 'goicuoc' );
        $fast = Input::get ( 'fast' );

        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

       
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;
        $code = 1;
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
           
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            
            
            
            try {
            if($gc_name == '0'){
            $code = 1;
             $tong= DB::table('logcharging'.$year.$month)
             ->select(DB::raw('sum(PRICE) as c'))
             ->where('TIME_REQUEST', '>=', $runtime)
             ->where('TIME_REQUEST', '<=', 
                $endofday)
           ->where('ERROR_DESC','Successful')->get();
            $DK_SMS=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','RENEW')
            ->where('CHANNEL_TYPE','SMS')
            ->where('ERROR_DESC','Successful')
            ->get();
            
             $GH_SMS=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','REG')
            ->where('CHANNEL_TYPE','SMS')
            ->where('ERROR_DESC','Successful')
            ->get();
            $WEB=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','REG')
            ->where('CHANNEL_TYPE','WEB')
            ->where('ERROR_DESC','Successful')
            ->get();
             
            $WAP=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','REG')
            ->where('CHANNEL_TYPE','WAP')
            ->where('ERROR_DESC','Successful')
            ->get();
            $GH_WAP= DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','RENEW')
            ->where('CHANNEL_TYPE','WAP')
            ->where('ERROR_DESC','Successful')
            ->get();           
            $GH_WEB= DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','RENEW')
            ->where('CHANNEL_TYPE','WEB')
            ->where('ERROR_DESC','Successful')
            ->get();
            $khac=DB::table('logcharging'.$year.$month)
            ->select(DB::raw('sum(PRICE) as c'))
            ->where('TIME_REQUEST', '>=', $runtime)
            ->where('TIME_REQUEST', '<=', 
                $endofday)           
            ->where('CHANNEL_TYPE','!=','WEB')
            ->where('CHANNEL_TYPE','!=','SMS')
            ->where('CHANNEL_TYPE','!=','WAP')
           ->where('ERROR_DESC','Successful')
            ->get();

           
             $Goi_ngay=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->whereIN('ORIGINALPRICE',['2000','1000'])
             ->where('ERROR_DESC','Successful')->get();
             
             $thuebao_dk=DB::table('logcharging'.$year.$month)
             ->select(DB::raw('count(*) as c'))
             ->where('TIME_REQUEST', '>=', $runtime)
             ->where('TIME_REQUEST', '<=', 
            $endofday)
             ->where('ERROR_DESC','Successful')
             ->where('REASON','REG')

             ->get();

             $thuebao_huy=DB::table('logcharging'.$year.$month)
             ->select(DB::raw('count(*) as c'))
             ->where('TIME_REQUEST', '>=', $runtime)
             ->where('TIME_REQUEST', '<=', 
            $endofday)
             ->where('ERROR_DESC','Successful')
             ->where('REASON','UNREG')

             ->get();

        
        }else{
            $code = 2;
            $giahan = substr_replace($gc_name, 'GH_', 0, 3);
            $tong= DB::table('logcharging'.$year.$month)
             ->select(DB::raw('sum(PRICE) as c'))
             ->where('TIME_REQUEST', '>=', $runtime)
             ->where('TIME_REQUEST', '<=', 
                $endofday)
           ->where('ERROR_DESC','Successful')
            ->where('COMMAND_CODE', $gc_name)
           ->get(); 
           $DK_SMS=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','RENEW')
            ->where('CHANNEL_TYPE','SMS')
            ->where('ERROR_DESC','Successful')
             ->where('COMMAND_CODE', $gc_name)
            ->get();
            
             $GH_SMS=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','REG')
            ->where('CHANNEL_TYPE','SMS')
            ->where('ERROR_DESC','Successful')
             ->where('COMMAND_CODE', $gc_name)
            ->get();
            $WEB=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','REG')
            ->where('CHANNEL_TYPE','WEB')
            ->where('ERROR_DESC','Successful')
             ->where('COMMAND_CODE', $gc_name)
            ->get();
             
            $WAP=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','REG')
            ->where('CHANNEL_TYPE','WAP')
            ->where('ERROR_DESC','Successful')
            ->get();
            $GH_WAP= DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','RENEW')
            ->where('CHANNEL_TYPE','WAP')
            ->where('ERROR_DESC','Successful')
             ->where('COMMAND_CODE', $gc_name)
            ->get();           
            $GH_WEB= DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('REASON','RENEW')
            ->where('CHANNEL_TYPE','WEB')
            ->where('ERROR_DESC','Successful')
             ->where('COMMAND_CODE', $gc_name)
            ->get();
            $khac=DB::table('logcharging'.$year.$month)
            ->select(DB::raw('sum(PRICE) as c'))
            ->where('TIME_REQUEST', '>=', $runtime)
            ->where('TIME_REQUEST', '<=', 
                $endofday)           
            ->where('CHANNEL_TYPE','<>','WEB')
            ->where('CHANNEL_TYPE','<>','SMS')
            ->where('CHANNEL_TYPE','<>','WAP')
           ->where('ERROR_DESC','Successful')
            ->where('COMMAND_CODE', $gc_name)
            ->get();

           
             $Goi_ngay=  DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->whereIN('ORIGINALPRICE',['2000','1000'])
             ->where('ERROR_DESC','Successful')->get();
             
             $thuebao_dk=DB::table('logcharging'.$year.$month)
             ->select(DB::raw('count(*) as c'))
             ->where('TIME_REQUEST', '>=', $runtime)
             ->where('TIME_REQUEST', '<=', 
            $endofday)
             ->where('ERROR_DESC','Successful')
             ->where('REASON','REG')
             ->where('COMMAND_CODE', $gc_name)
             ->get();


             $thuebao_huy=DB::table('logcharging'.$year.$month)
             ->select(DB::raw('count(*) as c'))
             ->where('TIME_REQUEST', '>=', $runtime)
             ->where('TIME_REQUEST', '<=', 
            $endofday)
             ->where('ERROR_DESC','Successful')
             ->where('REASON','UNREG')
             ->where('COMMAND_CODE', $gc_name)
             ->get();
        }
            
            $cc = array("ngay"=>date('d/m/Y',strtotime($runtime)),  
                "tong"=>$this->pa($tong[0]->c),
                'SMS'=>$this->pa($GH_SMS[0]->c),
                'giahan_SMS'=>$this->pa($DK_SMS[0]->c),
                'WEB'=>$this->pa($WEB[0]->c),
                'giahan_WEB'=>$this->pa($GH_WEB[0]->c),
                'WAP'=>$this->pa($WAP[0]->c),
                'giahan_WAP'=>$this->pa($GH_WAP[0]->c),
                'khac'=>$this->pa($khac[0]->c),
                'luot_dangky'=>$this->pa($thuebao_dk[0]->c),
                'Huy'=>$this->pa($thuebao_huy[0]->c),
                'Thuebaohd'=>$this->pa(0),
                'goingay'=>$this->pa($Goi_ngay[0]->c),              
               
                );

            $articles []= $cc;
            $sumup[0]+=$cc['tong'];
            $sumup[1]+=$cc['SMS'];
            $sumup[2]+=$cc['goingay'];
            $sumup[3]=0;
            $sumup[4]+=$cc['giahan_WEB'];
            $sumup[5]+=$cc['WAP'];
            $sumup[6]+=$cc['giahan_WAP'];
            $sumup[7]+=$cc['khac'];
            $sumup[8]+=$cc['luot_dangky'];
            $sumup[9]+=$cc['Huy'];
            $sumup[10]+=$cc['Thuebaohd'];
            } catch (\Illuminate\Database\QueryException $e) {
            }     
        
            $runtime = $tomorrowdate;

        }
        $articles = array_reverse($articles);
        $goicuoc = GoiCuoc::all();                 
        return view('backend/bao_cao/thong_ke_doanh_thu',compact('articles','sumup','fast', 'goicuoc', 'gc_name', 'code'));
    }
       function pa($a){
       if (!isset($a)) return 0; 
            else if (!$a) return 0;else return $a;
   }
    public function thong_ke_thue_bao()
    {   
	
		if (!Auth::check()) return \Redirect::to("admincp/login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $gc_name = Input::get ( 'goicuoc' );
        $fast = Input::get ( 'fast' );

        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

        
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;
        $code = 1;
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            try {
            if($gc_name == '0'){
            $code = 1;
            $so_tb_hoat_dong = DB::table('logcharging'.$year.$month)->select(DB::raw('count(DISTINCT SUBID) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','<>','UNREG')->get();

                // chu y o day : coi so tb = luot  : mac du chung co the khac nhau nhung tinh luot hay tinh so tb thi cung ko co khac nhau gi quan trong
                // luot dk thanh cong bao gom ca CONTENT
            $so_tb_dang_ky_thanh_cong = DB::table('logcharging'.$year.$month)
             ->select(DB::raw('count(*) as c'))
             ->where('TIME_REQUEST', '>=', $runtime)
             ->where('TIME_REQUEST', '<=', 
            $endofday)
             ->where('ERROR_DESC','Successful')
             ->where('REASON','REG')

             ->get();


            $so_tb_gia_han_that_bai = DB::table('logcharging'.$year.$month)->select(DB::raw('count(DISTINCT SUBID) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','RENEW')->where('ERROR_DESC','<>',$this->SUCCESS)->get();
            $so_tb_gia_han_thanh_cong = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','RENEW')->where('ERROR_DESC',$this->SUCCESS)->get();
            $tong_so_tb_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','UNREG')->get();
            $tong_so_tb_bi_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','=','UNREG')->where($this->CHANNEL_FIELD,'=',$this->APP_CSKH)->where('ERROR_DESC',$this->SUCCESS)->get();

            $tong_so_tb_tu_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','=','UNREG')->where($this->CHANNEL_FIELD,'<>',$this->APP_CSKH)->where('ERROR_DESC',$this->SUCCESS)->get();
            
        }else{
            $code = 2;
            $so_tb_hoat_dong = DB::table('logcharging'.$year.$month)->select(DB::raw('count(DISTINCT SUBID) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('COMMAND_CODE', $gc_name)->where('REASON','<>','UNREG')->get();
               
            $so_tb_dang_ky_thanh_cong = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','<>','UNREG')->where('COMMAND_CODE', $gc_name)->where('REASON','<>','RENEW')->where('ERROR_DESC',$this->SUCCESS)->get();

            $so_tb_gia_han_that_bai = DB::table('logcharging'.$year.$month)->select(DB::raw('count(DISTINCT SUBID) as c'))->where('COMMAND_CODE', $gc_name)->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','RENEW')->where('ERROR_DESC','<>',$this->SUCCESS)->get();
            $so_tb_gia_han_thanh_cong = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('COMMAND_CODE', $gc_name)->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','RENEW')->where('ERROR_DESC',$this->SUCCESS)->get();
            $tong_so_tb_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('COMMAND_CODE', $gc_name)->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','=','UNREG')->where('ERROR_DESC',$this->SUCCESS)->get();
            $tong_so_tb_bi_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('REASON','UNREG')->where('COMMAND_CODE', $gc_name)->where('ERROR_DESC',$this->SUCCESS)->get();
            $tong_so_tb_tu_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','=','UNREG')->where('COMMAND_CODE', $gc_name)->where($this->CHANNEL_FIELD,'<>',$this->APP_CSKH)->where('ERROR_DESC',$this->SUCCESS)->get();
            

        }
            
            $cc = array("ngay"=>date('d/m/Y',strtotime($runtime)),  
                "so_tb_hoat_dong"=>$this->pa($so_tb_hoat_dong[0]->c),
                'thanhcong'=>$this->pa($so_tb_dang_ky_thanh_cong[0]->c),
                'thatbai'=>$this->pa($so_tb_gia_han_that_bai[0]->c),
                'ghtc'=>$this->pa($so_tb_gia_han_thanh_cong[0]->c),
                'tbhuy'=>$this->pa($tong_so_tb_huy[0]->c),
                'bihuy'=>$this->pa($tong_so_tb_bi_huy[0]->c),
                'tong_so_tb_tu_huy'=>$this->pa($tong_so_tb_tu_huy[0]->c)
                );

            $articles []= $cc;
            
             $sumup[0] += $cc['so_tb_hoat_dong'];
        $sumup[1] +=  $cc['thanhcong'];                             
        $sumup[2] += $cc['thatbai']  ;                            
        $sumup[3] += $cc['ghtc'] ;                                 
        $sumup[4] += $cc['tbhuy']  ;                                
        $sumup[5] += $cc['bihuy'] ;                                   
        $sumup[6] += $cc['tong_so_tb_tu_huy'] ;

            } catch (\Illuminate\Database\QueryException $e) {
            }       
        
            $runtime = $tomorrowdate;

        }

    
        $articles = array_reverse($articles);
        $goicuoc = GoiCuoc::all();  
        //print_r($sumup);die();
        return view('backend/bao_cao/thong_ke_thue_bao',compact('articles','sumup','fast', 'goicuoc', 'gc_name'));
    }
    public function thong_dang_ky_huy()
    {

    
        if (!Auth::check()) return \Redirect::to("admincp/login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $gc_name = Input::get ( 'goicuoc' );
        $fast = Input::get ( 'fast' );

        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

        
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;
        $code = 1;
        $sdt=[];
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            try {
              $so_tb_dk = DB::table('logcharging'.$year.$month)
              ->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','REG')
              ->where('ERROR_DESC','Successful')
              ->get();
            
              $sdt_dk= DB::table('logcharging'.$year.$month)
              ->select('SUBID')->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','REG')
              ->where('ERROR_DESC','Successful')
              ->get();
              foreach ($sdt_dk as $key => $value) {
                  $sdt[]=$value->SUBID;
              }
              $so_tb_huy=DB::table('logcharging'.$year.$month)
              ->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
            $endofday)->where('REASON','UNREG')
              ->where('ERROR_DESC','Successful')
              ->whereIn('SUBID',$sdt)
              ->get();
             
             $cc = array("ngay"=>date('d/m/Y',strtotime($runtime)),  
                "sdt_dk"=>$this->pa($so_tb_dk[0]->c),
                'so_tb_huy'=>$this->pa($so_tb_huy[0]->c)
                
                );

            $articles []= $cc;
            $sumup[0] += $cc['sdt_dk'];
            $sumup[1] +=  $cc['so_tb_huy'];
            } catch (\Illuminate\Database\QueryException $e) {
            }       
        
            $runtime = $tomorrowdate;

        }

    
        $articles = array_reverse($articles);
        $goicuoc = GoiCuoc::all();  
        //print_r($sumup);die();
        return view('backend/bao_cao/thong_ke_dangkyhuy',compact('articles','sumup'));
    }
    public function thong_ke_thue_bao_goi()
    {   
    
        if (!Auth::check()) return \Redirect::to("admincp/login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $gc_name = Input::get ( 'goicuoc' );
        $fast = Input::get ( 'fast' );

        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

        //$ranges = $this->spanquery($start,$end);
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;
        $code = 1;
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            
            
            
            try {
            $CAUVANG = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)
            ->where('COMMAND_CODE','TCV')
            ->where('ERROR_DESC',$this->SUCCESS)
            ->get();
            $GIAIMATRANDAU=DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('COMMAND_CODE','GM')
            ->where('ERROR_DESC',$this->SUCCESS)
            ->get();
            
            $TINTUCTONGHOP=DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                $endofday)->where('COMMAND_CODE','DK')
            ->where('ERROR_DESC',$this->SUCCESS)
            ->get();
            
            $cc = array("ngay"=>date('d/m/Y',strtotime($runtime)),  
               
                'CAUVANG'=>$this->pa($CAUVANG[0]->c),
                'GIAIMATRANDAU'=>$this->pa($GIAIMATRANDAU[0]->c),
                'TINTUCTONGHOP'=>$this->pa($TINTUCTONGHOP[0]->c),
                
                );

            $articles []= $cc;
            $sumup[0]=$cc['CAUVANG'];
            $sumup[1]=$cc['GIAIMATRANDAU'];
            $sumup[2]=$cc['TINTUCTONGHOP'];
            $sumup[3]=$cc['CAUVANG']+$cc['GIAIMATRANDAU']+$cc['TINTUCTONGHOP'];
            
            

            } catch (\Illuminate\Database\QueryException $e) {
            }       
        
            $runtime = $tomorrowdate;

        }


        $articles = array_reverse($articles);
        $goicuoc = Cp::all();  
        //print_r($articles);die();
        
       
        return view('backend/bao_cao/thong_ke_thue_bao_goi',compact('articles','sumup','fast'));
    }

    public function lichsudangkyhuy(Request $request){
        if (!Auth::check()) return \Redirect::to("admincp/login");
        if(Auth::user()->user_type_id == 100){
            Auth::logout();return \Redirect::to("admincp/login");
        }
        
        // $u = UserTypes::find(Auth::user()->user_type_id);
        // $up = explode(',',$u->permissions);
        // if (!in_array('quan_ly_thue_bao',$up)) return \Redirect::to("/");

        $phone = Auth::user()->USER_ID;
        $goi_cuoc = GoiCuoc::all();   
        

        return view('backend/thue_bao/lichsudangkyhuy', compact('phone', 'goi_cuoc'));

    }
    public function caidat_thuebao(Request $request){
    if (!Auth::check()) return \Redirect::to("admincp/login");
    if(Auth::user()->user_type_id == 100){
        Auth::logout();return \Redirect::to("admincp/login");
    }
    
     $up = User::find(Auth::user()->user_type_id);
   // $up = explode(',',$u->permissions);
     //return $up->user_type_id;die();
     if ($up->user_type_id==10) return \Redirect::to("/");

    $phone = Auth::user()->USER_ID;
    $goi_cuoc = GoiCuoc::all();   
    $hung = KhachHang::where('USER_ID',$phone)->get();
    $article = KhachHang::where('USER_ID',$phone)->first();  
    if (!$article) {
        $article =  DB::table('customer_cancel')->where('USER_ID',$phone)->first();
    }   
    $custo = KhachHang::where('USER_ID', $phone)->get();

        // $custo = KhachHang::where('USER_ID', $MSISDN)->select('PACKAGE', DB::raw('count(PACKAGE) as total'))
        //         ->groupBy('PACKAGE')
        //         ->get();

    if (count($custo) > 1) {
        $customer = $custo;
    }

    //return $customer;
    return view('backend/thue_bao/caidatdichvu', compact('phone', 'goi_cuoc','article','customer'));

}
public function lichsutrucuoc(Request $request){
    if (!Auth::check()) return \Redirect::to("admincp/login");
    if(Auth::user()->user_type_id == 100){
        Auth::logout();return \Redirect::to("admincp/login");
    }
    
    // $u = UserType::find(Auth::user()->user_type_id);
    // $up = explode(',',$u->permissions);
    // if (!in_array('quan_ly_thue_bao',$up)) return \Redirect::to("/");

    $phone = Auth::user()->USER_ID;
    $goi_cuoc = GoiCuoc::all();   
    


    return view('backend/thue_bao/lichsutrucuoc', compact('phone', 'goi_cuoc'));

}
public function timkiem_lichsutrucuoc(){

    if (!Auth::check()) return \Redirect::to("admincp/login");
    if(Auth::user()->user_type_id == 100){
        Auth::logout();return \Redirect::to("admincp/login");
    }
    if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
        $end= date("Y-m-d")." 23:59:59";
        if (empty(Input::get ( 'time_bat_dau' )))
          $start = date('Y-m-d H:i:s', strtotime('-7 days'));
      else
          $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
  } else {
    $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
    $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
}

        //$start = "2010-01-01 00:00:01"; // dont use start time, always start with this

$runtime = $start;
    $type1 = Input::get ( 'type' ); //COMMAND_CODE
    $phone_number = Input::get ( 'subscriber_number' ); 
    $goi_cuoc = GoiCuoc::all();
    $user_id = Auth::user();
    $user_id->USER_ID = $phone_number;
    $user_id->save();
    $phone = Auth::user()->USER_ID;     

    $ranges = $this->spanquery($start,$end);
    $articles = collect(array());
    for ($i=count($ranges)-1; $i>=0; $i--) {
        try {
            $query = DB::table('logcharging'.$ranges[$i][0].sprintf("%02d", $ranges[$i][1]))->where('SUBID',$phone_number)->where('TIME_REQUEST', '>=', $ranges[$i][2])->where('TIME_REQUEST', '<=', 
                $ranges[$i][3])->where('REASON', '<>', 'UNREG');

            if($type1 == '0'){
                $query = $query;
            }else{
                $query = $query->where('COMMAND_CODE', $type1);
                $dich_vu = GoiCuoc::where('package_code', $type1)->first();
            }
            
            $articles = $articles->merge($query->orderBy('TIME_REQUEST', 'desc')->get());
            
        } catch (\Illuminate\Database\QueryException $e) {
        }           
    }

    $bat_dau =  (date('Y-m-d', strtotime($start)));
    $ket_thuc = (date('Y-m-d', strtotime($end)));




    return view('backend/thue_bao/lichsutrucuoc', compact('phone', 'goi_cuoc', 'query', 'phone', 'bat_dau', 'ket_thuc', 'dich_vu'))->withDetails($articles);  
}
 function spanquery($start,$end){
        $ranges = array();
        // calculate ranges for merging collections
        // find the month of start  and find the month of end
        $monthstart = intval(date("n",strtotime($start)));
        $yearstart = intval(date('Y', strtotime($start)));
        $daystart = intval(date('j', strtotime($start)));
        $monthend = intval(date("n",strtotime($end)));
        $yearend = intval(date('Y', strtotime($end)));
        $dayend = intval(date('j', strtotime($end)));
        $monthrun = $monthstart;
        $yearrun = $yearstart;
        if (($yearend==$yearstart)&&($monthend==$monthstart)) {
            if (($daystart>$dayend)){
                 //return array();
            } else 
                $ranges[]= array($yearstart,$monthstart, $start,$end);
        } else 
        {
            while ((($monthrun<=$monthend)&&($yearrun==$yearend))||($yearrun<$yearend)){
                if (($monthrun==$monthstart)&&($yearrun==$yearstart)){
                    $ranges []= array($yearstart,$monthstart, $start,date("Y-m-t", strtotime($start))." 23:59:59");
                } else
                if (($monthrun==$monthend)&&($yearrun==$yearend)){
                    $ranges []= array($yearend,$monthend, date("Y-m-01", strtotime($end))." 00:00:00",$end);
                } else {
                    $firstday = $yearrun."-".sprintf("%02d",$monthrun)."-01 00:00:00";                  
                    $ranges []= array($yearrun,$monthrun,$firstday,date("Y-m-t", strtotime($firstday))." 23:59:59");
                }
                $monthrun++;
                if  ($monthrun==13) { $monthrun = 1; $yearrun++;}
            }
        }
        /*
        echo "<pre>";
        print_r($ranges);
        echo "</pre>";
        die();
        */
        
        return $ranges;
    } 
public function lichsusudung(Request $request){
    if (!Auth::check()) return \Redirect::to("admincp/login");
    if(Auth::user()->user_type_id == 100){
        Auth::logout();return \Redirect::to("admincp/login");
    }
    
    // $u = UserType::find(Auth::user()->user_type_id);
    // $up = explode(',',$u->permissions);
    // if (!in_array('quan_ly_thue_bao',$up)) return \Redirect::to("/");

    $phone = Auth::user()->USER_ID;
    $goi_cuoc = GoiCuoc::all();   
    

    return view('backend/thue_bao/lichsusudung', compact('phone', 'goi_cuoc'));

}
public function timkiem_lichsusudung(){
    $type1 = Input::get ( 'type' ); //COMMAND_CODE
    $phone_number = Input::get ( 'subscriber_number' ); 
    $goi_cuoc = GoiCuoc::all();
    $user_id = Auth::user();
    $user_id->USER_ID = $phone_number;
    $user_id->save();
    $phone = Auth::user()->USER_ID;

    if (!Auth::check()) return \Redirect::to("login");
    
    


    if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
        $end= date("Y-m-d")." 23:59:59";
        if (empty(Input::get ( 'time_bat_dau' )))
          $start = date('Y-m-d H:i:s', strtotime('-7 days'));
      else
          $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
  } else {
    $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
    $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
}



$articles = array();
$sumup=array(0,0,0,0,0,0,0,0,0,0,0);
$runtime = $start;


$month = (date("m",strtotime($runtime)));
$year = (date('Y', strtotime($runtime)));




$query = CustomerLSSD::where('USER_ID',$phone_number)->where('created_at', '>=', $start )->where('created_at', '<=', $end )->orderBy('created_at', 'desc');

if($type1 == '0'){
    $query = $query->get();
}else{
        $query = $query->where('goi_cuoc', $type1)->get();

    $dich_vu = GoiCuoc::where('package_code', $type1)->first();

}

$bat_dau =  (date('Y-m-d', strtotime($start)));
$ket_thuc = (date('Y-m-d', strtotime($end)));




return view('backend/thue_bao/lichsusudung', compact('phone', 'goi_cuoc', 'query', 'phone', 'bat_dau', 'ket_thuc', 'dich_vu'));   
}
public function lichsumomt(Request $request){
    if (!Auth::check()) return \Redirect::to("admincp/login");
    if(Auth::user()->user_type_id == 100){
        Auth::logout();return \Redirect::to("admincp/login");
    }
    
    // $u = UserType::find(Auth::user()->user_type_id);
    // $up = explode(',',$u->permissions);
    // if (!in_array('quan_ly_thue_bao',$up)) return \Redirect::to("/");

    $phone = Auth::user()->USER_ID;
    $goi_cuoc = GoiCuoc::all();   
    

    return view('backend/thue_bao/lichsumomt', compact('phone', 'goi_cuoc'));

}
public function timkiem_lichsumomt(){

    if (!Auth::check()) return \Redirect::to("admincp/login");
    if(Auth::user()->user_type_id == 100){
        Auth::logout();return \Redirect::to("admincp/login");
    }
    if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
        $end= date("Y-m-d")." 23:59:59";
        if (empty(Input::get ( 'time_bat_dau' )))
          $start = date('Y-m-d H:i:s', strtotime('-7 days'));
      else
          $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
  } else {
    $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
    $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
}

        //$start = "2010-01-01 00:00:01"; // dont use start time, always start with this

$runtime = $start;
    $type1 = Input::get ( 'type' ); //COMMAND_CODE
    $phone_number = Input::get ( 'subscriber_number' ); 
    $goi_cuoc = GoiCuoc::all();
    $user_id = Auth::user();
    $user_id->USER_ID = $phone_number;
    $user_id->save();
    $phone = Auth::user()->USER_ID;     

    $ranges = $this->spanquery($start,$end);
    $mt_list = collect(array());
    $mo_list = collect(array());
    for ($i=count($ranges)-1; $i>=0; $i--) {
        try {
            $query_mo = DB::table('mo'.$ranges[$i][0].sprintf("%02d", $ranges[$i][1]))
            // ->where('MO_TYPE', '!=', 3)
            ->where('USER_ID',$phone_number)
            ->where('RECEIVE_DATE', '>=', $ranges[$i][2])
            ->where('RECEIVE_DATE', '<=', $ranges[$i][3]);

            $query_mt = DB::table('mt'.$ranges[$i][0].sprintf("%02d", $ranges[$i][1]))
            ->where('USER_ID',$phone_number)
            ->where('SUBMIT_DATE', '>=', $ranges[$i][2])
            ->where('SUBMIT_DATE', '<=', $ranges[$i][3]);

            if($type1 == '0'){
                $query_mo = $query_mo;
                $query_mt = $query_mt;
            }else{
                $query_mo = $query_mo->where('COMMAND_CODE', $type1);
                $query_mt = $query_mt->where('COMMAND_CODE', $type1);
                $dich_vu = GoiCuoc::where('package_code', $type1)->first();
            }
            
            $mt_list = $mt_list->merge($query_mt->orderBy('SUBMIT_DATE', 'desc')->get());
            $mo_list = $mo_list->merge($query_mo->orderBy('RECEIVE_DATE', 'desc')->get());
            
        } catch (\Illuminate\Database\QueryException $e) {
        }           
    }

    $bat_dau =  (date('Y-m-d', strtotime($start)));
    $ket_thuc = (date('Y-m-d', strtotime($end)));       

    //return $mo_list;die();
    return view('backend/thue_bao/lichsumomt', compact('phone', 'goi_cuoc', 'mt_list', 'mo_list', 'phone', 'bat_dau', 'ket_thuc', 'dich_vu'))->withDetails($mt_list, $mo_list);   
}
    public function timkiem_lichsudangkyhuy()
    {

        if (!Auth::check()) return \Redirect::to("admincp/login");
        if(Auth::user()->user_type_id == 100){
            Auth::logout();return \Redirect::to("admincp/login");
        }
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d H:i:s', strtotime('-7 days'));
          else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
      } else {
        $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
        $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
    }

            //$start = "2010-01-01 00:00:01"; // dont use start time, always start with this

    $runtime = $start;
        $type1 = Input::get ( 'type' ); //COMMAND_CODE
        $phone_number = Input::get ( 'subscriber_number' ); 
        $goi_cuoc = GoiCuoc::all();
        $user_id = Auth::user();
        $user_id->USER_ID = $phone_number;
        $user_id->save();
        $phone = Auth::user()->USER_ID;     

        $ranges = $this->spanquery($start,$end);
        $articles = collect(array());
        for ($i=count($ranges)-1; $i>=0; $i--) {
            try {

                $query = DB::table('logcharging'.$ranges[$i][0].sprintf("%02d", $ranges[$i][1]))->where('SUBID',$phone_number)->where('TIME_REQUEST', '>=', $ranges[$i][2])->where('TIME_REQUEST', '<=', 
                    $ranges[$i][3])->where('REASON', '<>', 'RENEW');

                if($type1 == '0'){
                    $query = $query;
                }else{
                    $query = $query->where('COMMAND_CODE', $type1);
                    $dich_vu = GoiCuoc::where('package_code', $type1)->first();
                }
                
                $articles = $articles->merge($query->orderBy('TIME_REQUEST', 'desc')->get());
               
            } catch (\Illuminate\Database\QueryException $e) {
            }           
        }
        //return count($ranges);
        $bat_dau =  (date('Y-m-d', strtotime($start)));
        $ket_thuc = (date('Y-m-d', strtotime($end)));


        return view('backend/thue_bao/lichsudangkyhuy', compact('phone', 'goi_cuoc', 'article', 'phone', 'bat_dau', 'ket_thuc', 'dich_vu'))->withDetails($articles);
    }
    public function caidat_dichvu(Request $request){
       if (!Auth::check()) return \Redirect::to("admincp/login");
        if(Auth::user()->user_type_id == 100){
            Auth::logout();return \Redirect::to("admincp/login");
        }
        
      

        $q = \Request::get('keyword');
        if($q[0] == 0){
            $phone_number = substr_replace($q, '84', 0, 1);
        }else{
            $phone_number = $q;
        }
        $b = CustomerHistory::where('USER_ID', $phone_number)->first();
        $user_id = Auth::user();
        $user_id->USER_ID = $phone_number;
        $user_id->save();
        $phone = Auth::user()->USER_ID;
        $goi_cuoc = GoiCuoc::all();   
        $article = KhachHang::where('USER_ID',$phone)->first();  
        if (!$article) {
            $article =  DB::table('customer_cancel')->where('USER_ID',$phone)->first();
        }   
        $custo = KhachHang::where('USER_ID', $phone)->get();

            // $custo = KhachHang::where('USER_ID', $MSISDN)->select('PACKAGE', DB::raw('count(PACKAGE) as total'))
            //         ->groupBy('PACKAGE')
            //         ->get();

        {
            $customer = $custo;
        }

        //return $customer[0]->COMMAND_CODE;die();
         return view('backend/thue_bao/caidatdichvu', compact('phone', 'goi_cuoc','article','customer','b'));

    }
    public function huy_dich_vu($USER_ID,$id)
    {
        $Moquue=new \App\Moqueue;
        $Moquue->USER_ID=$USER_ID;
        $Moquue->SERVICE_ID='9389';
        $Moquue->MOBILE_OPERATOR='VMS';
        $goicuoc=GoiCuoc::where('id',$id)->get();
        foreach ($goicuoc as $key => $value) {
                $goicuoc=$value->cancelcode;
             }   
        $Moquue->INFO= $goicuoc;    
        $Moquue->RECIEVE_DATE= date('Y/m/d  H:i:s');
        $Moquue->CHANNEL_TYPE="CSKH";
        $Moquue->CPID=1;
        $Moquue->save();
         return \Redirect::to('admincp/cskh/caidatdichvu');
    }
    public function dangkyDichVu($USER_ID,$id)
    {
        $moq=new \App\Moqueue;
        $moq->USER_ID = $USER_ID;
        $moq->SERVICE_ID = '9389';
        $moq->MOBILE_OPERATOR = 'VMS';
        $goicuoc=GoiCuoc::where('id',$id)->get();
        foreach ($goicuoc as $key => $value) {
                //$goicuoc=
                $moq->INFO = $value->register_code;;
             } 
        
        $moq->RECIEVE_DATE = date('Y-m-d H:i:s');
        $moq->REQUEST_ID = date('YmdHis');
        $moq->CHANNEL_TYPE = 'CSKH';
        $moq->CPID = 1;
                   //eturn $moq->CPID;
        $moq->save();
         return \Redirect::to('admincp/cskh/caidatdichvu');
    }
     public function thong_ke_thue_bao_dang_ky()
    {   
    
        if (!Auth::check()) return \Redirect::to("admincp/login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        
        $fast = Input::get ( 'fast' );
        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }       

        //$ranges = $this->spanquery($start,$end);
        $articles = array();    
                $sumup = array(
                                    'tong_luot_dk'=>0,
                                    'so_tb_dang_ky_free'=>0,                                
                                    'so_tb_dang_ky_mat_cuoc'=>0,                                    
                                    'so_tb_dk_thanh_cong_sms'=>0,
                                    'so_tb_dk_thanh_cong_wap'=>0,
                                    'so_tb_dk_thanh_cong_app'=>0,
                                    'so_tb_dk_thanh_cong_cskh'=>0,  
                                    'so_tb_dk_thanh_cong_api'=>0,                               
                                    );
            $runtime = $start; 
            while ($runtime<$end) {
                $tomorrow = strtotime("tomorrow", strtotime($runtime));
                $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
                $endofday = date('Y-m-d H:i:s',$tomorrow-1);
                //echo "$runtime $endofday <br/>";
                $month = (date("m",strtotime($runtime)));
                $year = (date('Y', strtotime($runtime)));
                
                $yesterday = strtotime("yesterday", strtotime($runtime));
                $yesterdaydate = date('Y-m-d H:i:s',$yesterday);
                $endofyesterdayday = date('Y-m-d H:i:s', strtotime("tomorrow", $yesterday)-1);
                
                try {
                
            
            
                // chu y o day : coi so tb = luot  : mac du chung co the khac nhau nhung tinh luot hay tinh so tb thi cung ko co khac nhau gi quan trong
                // luot dk thanh cong bao gom ca CONTENT
                $tong_luot_dk = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','<>','UNREG')
                ->where('ERROR_DESC','Successful')
                ->where('REASON','<>','RENEW')->get();
                        
                $so_tb_dang_ky_free = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','<>','UNREG')->where('REASON','<>','RENEW')->where('PRICE',0)->where('ERROR_DESC',$this->SUCCESS)->get();
                $so_tb_dang_ky_mat_cuoc = DB::table('logcharging'.$year.$month)
                ->select(DB::raw('count(*) as c'))
                ->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','REG')
                ->where('PRICE','!=','0')->where('ERROR_DESC',$this->SUCCESS)->get();
                $so_tb_dk_thanh_cong_sms = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','<>','UNREG')->where('REASON','<>','RENEW')->where($this->CHANNEL_FIELD,'SMS')->where('ERROR_DESC',$this->SUCCESS)->get();
                $so_tb_dk_thanh_cong_wap = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','<>','UNREG')->where('REASON','<>','RENEW')->where($this->CHANNEL_FIELD,'WAP')->where('ERROR_DESC',$this->SUCCESS)->get();
                $so_tb_dk_thanh_cong_app = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','<>','UNREG')->where('REASON','<>','RENEW')->where($this->CHANNEL_FIELD,'APP')->where('ERROR_DESC',$this->SUCCESS)->get();
                $so_tb_dk_thanh_cong_cskh = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','<>','UNREG')->where('REASON','<>','RENEW')->where($this->CHANNEL_FIELD,$this->APP_CSKH)->where('ERROR_DESC',$this->SUCCESS)->get();
                $so_tb_dk_thanh_cong_api = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', 
                    $endofday)->where('REASON','<>','UNREG')->where('REASON','<>','RENEW')->where($this->CHANNEL_FIELD,'API')->where('ERROR_DESC',$this->SUCCESS)->get();
                                                                                                                                
            
    
                $cc = array("ngay"=>date('Y-m-d',strtotime($runtime)),
                                    'tong_luot_dk'=>$this->pa($tong_luot_dk[0]->c),  
                                    'so_tb_dang_ky_free'=>$this->pa($so_tb_dang_ky_free[0]->c) ,                                
                                    'so_tb_dang_ky_mat_cuoc'=>$this->pa($so_tb_dang_ky_mat_cuoc[0]->c),                                 
                                    'so_tb_dk_thanh_cong_sms'=>$this->pa($so_tb_dk_thanh_cong_sms[0]->c),   
                                    'so_tb_dk_thanh_cong_wap'=>$this->pa($so_tb_dk_thanh_cong_wap[0]->c),
                                    'so_tb_dk_thanh_cong_app'=>$this->pa($so_tb_dk_thanh_cong_app[0]->c),
                                    'so_tb_dk_thanh_cong_cskh'=>$this->pa($so_tb_dk_thanh_cong_cskh[0]->c),
                                    'so_tb_dk_thanh_cong_api'=>$this->pa($so_tb_dk_thanh_cong_api[0]->c),
                                );
                $articles []= $cc;
                // some numbers here wont be valid because the sum of everyday does not mean the total here
                // the total sometimes is just the last day, i.e : so_tb_hoat_dong not valid here
                $sumup['tong_luot_dk'] += $cc['tong_luot_dk'];
                $sumup['so_tb_dang_ky_free'] +=  $cc['so_tb_dang_ky_free'];                             
                $sumup['so_tb_dang_ky_mat_cuoc'] += $cc['so_tb_dang_ky_mat_cuoc']  ;                            
                $sumup['so_tb_dk_thanh_cong_sms'] += $cc['so_tb_dk_thanh_cong_sms'] ;                                   
                $sumup['so_tb_dk_thanh_cong_wap'] += $cc['so_tb_dk_thanh_cong_wap']  ;                              
                $sumup['so_tb_dk_thanh_cong_app'] += $cc['so_tb_dk_thanh_cong_app'] ;                                   
                $sumup['so_tb_dk_thanh_cong_cskh'] += $cc['so_tb_dk_thanh_cong_cskh'] ;                                 
                $sumup['so_tb_dk_thanh_cong_api'] += $cc['so_tb_dk_thanh_cong_api'] ;                       
            
                } catch (\Illuminate\Database\QueryException $e) {
                }       
                
                $runtime = $tomorrowdate;
            }
        $articles = array_reverse($articles);
       
       // return $tong_luot_dkngay01; die();
       
        return view('backend/bao_cao/thong_ke_thue_bao_dang_ky',compact('articles','sumup','fast'));
    }
    function thong_ke_truyen_thong_link(){
        
        if (!Auth::check()) return \Redirect::to("admincp/login");
        if(Auth::user()->user_type_id == 23){
            Auth::logout();return \Redirect::to("admincp/login");
        }
        $u = UserTypes::find(Auth::user()->user_type_id);
        $up = explode(',',$u->permissions);
        if (in_array('thong_ke_truyen_thong_link',$up) || Auth::user()->user_type_id == '1'){
        }else{
            return \Redirect::to("admincp/"); 
        }
        
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $cpname = Cpname::all();
        $cps = Cp::where('CHANNEL_TYPE', "WAP")->get();

        $cpid = Input::get ( 'cpid' );
        $articles = array();
        $sumup = array(
                                    'tong_doanh_thu'=>0,                              
                                    'doanh_thu_dang_ky'=>0,                                    
                                    'doanh_thu_gia_han'=>0,
                                    'doanh_thu_truy_thu'=>0,
                                    'dang_ky'=>0,                              
                                    'dang_ky_mien_phi'=>0,                                    
                                    'so_tb_hethong_huy'=>0,
                                    'huy'=>0,      
                                    );
        $runtime = $start;
        $cpid_wap = Cp::where('CHANNEL_TYPE','WAP')->pluck('id')->toArray();
        //return $cpid_wap;
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            $yesterday = strtotime("yesterday", strtotime($runtime));
            $yesterdaydate = date('Y-m-d H:i:s',$yesterday);
            $endofyesterdayday = date('Y-m-d H:i:s', strtotime("tomorrow", $yesterday)-1);
            
            try {
                $doanh_thu_dang_ky = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON', 'REG')->where('ERROR_DESC',$this->SUCCESS);

                $doanh_thu_gia_han = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON','=','RENEW')->where('ERROR_DESC',$this->SUCCESS);

                $doanh_thu_truy_thu = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON','=','RENEW')->whereColumn('PRICE','<>', 'ORIGINALPRICE')->where('ERROR_DESC',$this->SUCCESS);

                $dang_ky = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON', 'REG')->where('ERROR_DESC',$this->SUCCESS);

                $dang_ky_mien_phi = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('PRICE', 0)->where('REASON', 'REG')->where('ERROR_DESC',$this->SUCCESS);

                $huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON', 'UNREG')->where('ERROR_DESC',$this->SUCCESS);
            
                $so_tb_hethong_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON','=','UNREG')->where('USERNAME', '!=', '')->where('ERROR_DESC',$this->SUCCESS);
                if($cpid == '0'){
                    $doanh_thu_dang_ky = $doanh_thu_dang_ky->whereIn('CPID', $cpid_wap)->get();
                    $doanh_thu_gia_han = $doanh_thu_gia_han->whereIn('CPID', $cpid_wap)->get();
                    $doanh_thu_truy_thu = $doanh_thu_truy_thu->whereIn('CPID', $cpid_wap)->get();
                    $dang_ky = $dang_ky->whereIn('CPID', $cpid_wap)->get();
                    $dang_ky_mien_phi = $dang_ky_mien_phi->whereIn('CPID', $cpid_wap)->get();
                    $huy = $huy->whereIn('CPID', $cpid_wap)->get();
                    $so_tb_hethong_huy = $so_tb_hethong_huy->whereIn('CPID', $cpid_wap)->get();

                }else{

                    $doanh_thu_dang_ky = $doanh_thu_dang_ky->where('CPID', $cpid)->get();
                    $doanh_thu_gia_han = $doanh_thu_gia_han->where('CPID', $cpid)->get();
                    $doanh_thu_truy_thu = $doanh_thu_truy_thu->where('CPID', $cpid)->get();
                    $dang_ky = $dang_ky->where('CPID', $cpid)->get();
                    $dang_ky_mien_phi = $dang_ky_mien_phi->where('CPID', $cpid)->get();
                    $huy = $huy->where('CPID', $cpid)->get();
                    $so_tb_hethong_huy = $so_tb_hethong_huy->where('CPID', $cpid)->get();
                }

                $cc = array("ngay"=>date('d-m-Y',strtotime($runtime)),
                            'doanh_thu_dang_ky'=>$this->pa($doanh_thu_dang_ky[0]->c),
                            'doanh_thu_gia_han'=>$this->pa($doanh_thu_gia_han[0]->c),
                            'doanh_thu_truy_thu'=>$this->pa($doanh_thu_truy_thu[0]->c),
                            'dang_ky'=>$this->pa($dang_ky[0]->c),
                            'dang_ky_mien_phi'=>$this->pa($dang_ky_mien_phi[0]->c),
                            'huy'=>$this->pa($huy[0]->c),
                            'so_tb_hethong_huy'=>$this->pa($so_tb_hethong_huy[0]->c),
                );
                
                $articles []= $cc;

                $sumup['tong_doanh_thu'] += ($cc['doanh_thu_dang_ky']+
                    $cc['doanh_thu_gia_han']
                    );
                $sumup['doanh_thu_dang_ky'] += $cc['doanh_thu_dang_ky'];
                $sumup['doanh_thu_gia_han'] += $cc['doanh_thu_gia_han'];
                $sumup['doanh_thu_truy_thu'] += $cc['doanh_thu_truy_thu'];
                $sumup['dang_ky'] +=  $cc['dang_ky'];
                $sumup['huy'] +=  $cc['huy'];                       
                $sumup['so_tb_hethong_huy'] += $cc['so_tb_hethong_huy'] ;
            
            
            }catch (\Illuminate\Database\QueryException $e) {
                }       
                
                $runtime = $tomorrowdate;
        }
        return view('backend\truyen_thong\thong_ke_link_truyenthong',compact('cpid','cps','articles','sumup', 'start', 'end'));
    }
    
    function thong_ke_truyen_thong_sms(){
        
        if (!Auth::check()) return \Redirect::to("admincp/login");
        if(Auth::user()->user_type_id == 23){
            Auth::logout();return \Redirect::to("admincp/login");
        }
        $u = UserTypes::find(Auth::user()->user_type_id);
        $up = explode(',',$u->permissions);
        if (in_array('thong_ke_truyen_thong_sms',$up) || Auth::user()->user_type_id == '1'){
        }else{
            return \Redirect::to("admincp/"); 
        }
        
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $cpname = Cpname::all();
        $cps = Cp::where('CHANNEL_TYPE', "SMS")->get();
        $cpid = Input::get ( 'cpid' );
        $articles = array();
        $sumup = array(
                                    'tong_doanh_thu'=>0,                              
                                    'doanh_thu_dang_ky'=>0,                                    
                                    'doanh_thu_gia_han'=>0,
                                    'doanh_thu_truy_thu'=>0,
                                    'dang_ky'=>0,                              
                                    'dang_ky_mien_phi'=>0,                                    
                                    'so_tb_hethong_huy'=>0,
                                    'huy'=>0,      
                                    );
        $runtime = $start;
        $cpid_sms = Cp::where('CHANNEL_TYPE','SMS')->pluck('id')->toArray();
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            $yesterday = strtotime("yesterday", strtotime($runtime));
            $yesterdaydate = date('Y-m-d H:i:s',$yesterday);
            $endofyesterdayday = date('Y-m-d H:i:s', strtotime("tomorrow", $yesterday)-1);
                
            try {
                $doanh_thu_dang_ky = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON', 'REG')->where('ERROR_DESC',$this->SUCCESS);

                $doanh_thu_gia_han = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON','=','RENEW')->where('ERROR_DESC',$this->SUCCESS);

                $doanh_thu_truy_thu = DB::table('logcharging'.$year.$month)->select(DB::raw('sum(PRICE) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON','=','RENEW')->whereColumn('PRICE','<>', 'ORIGINALPRICE')->where('ERROR_DESC',$this->SUCCESS);

                $dang_ky = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON', 'REG')->where('ERROR_DESC',$this->SUCCESS);

                $dang_ky_mien_phi = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('PRICE', 0)->where('REASON', 'REG')->where('ERROR_DESC',$this->SUCCESS);

                $huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON', 'UNREG')->where('ERROR_DESC',$this->SUCCESS);
            
                $so_tb_hethong_huy = DB::table('logcharging'.$year.$month)->select(DB::raw('count(*) as c'))->where('TIME_REQUEST', '>=', $runtime)->where('TIME_REQUEST', '<=', $endofday)->where('REASON','=','UNREG')->where('USERNAME', '!=', '')->where('ERROR_DESC',$this->SUCCESS);
                if($cpid == '0'){
                    $doanh_thu_dang_ky = $doanh_thu_dang_ky->whereIn('CPID', $cpid_sms)->get();
                    $doanh_thu_gia_han = $doanh_thu_gia_han->whereIn('CPID', $cpid_sms)->get();
                    $doanh_thu_truy_thu = $doanh_thu_truy_thu->whereIn('CPID', $cpid_sms)->get();
                    $dang_ky = $dang_ky->whereIn('CPID', $cpid_sms)->get();
                    $dang_ky_mien_phi = $dang_ky_mien_phi->whereIn('CPID', $cpid_sms)->get();
                    $huy = $huy->whereIn('CPID', $cpid_sms)->get();
                    $so_tb_hethong_huy = $so_tb_hethong_huy->whereIn('CPID', $cpid_sms)->get();

                }else{

                    $doanh_thu_dang_ky = $doanh_thu_dang_ky->where('CPID', $cpid)->get();
                    $doanh_thu_gia_han = $doanh_thu_gia_han->where('CPID', $cpid)->get();
                    $doanh_thu_truy_thu = $doanh_thu_truy_thu->where('CPID', $cpid)->get();
                    $dang_ky = $dang_ky->where('CPID', $cpid)->get();
                    $dang_ky_mien_phi = $dang_ky_mien_phi->where('CPID', $cpid)->get();
                    $huy = $huy->where('CPID', $cpid)->get();
                    $so_tb_hethong_huy = $so_tb_hethong_huy->where('CPID', $cpid)->get();
                }

                $cc = array("ngay"=>date('d-m-Y',strtotime($runtime)),
                            'doanh_thu_dang_ky'=>$this->pa($doanh_thu_dang_ky[0]->c),
                            'doanh_thu_gia_han'=>$this->pa($doanh_thu_gia_han[0]->c),
                            'doanh_thu_truy_thu'=>$this->pa($doanh_thu_truy_thu[0]->c),
                            'dang_ky'=>$this->pa($dang_ky[0]->c),
                            'dang_ky_mien_phi'=>$this->pa($dang_ky_mien_phi[0]->c),
                            'huy'=>$this->pa($huy[0]->c),
                            'so_tb_hethong_huy'=>$this->pa($so_tb_hethong_huy[0]->c),
                );
                
                $articles []= $cc;

                $sumup['tong_doanh_thu'] += ($cc['doanh_thu_dang_ky']+
                    $cc['doanh_thu_gia_han']
                    );
                $sumup['doanh_thu_dang_ky'] += $cc['doanh_thu_dang_ky'];
                $sumup['doanh_thu_gia_han'] += $cc['doanh_thu_gia_han'];
                $sumup['doanh_thu_truy_thu'] += $cc['doanh_thu_truy_thu'];
                $sumup['dang_ky'] +=  $cc['dang_ky'];
                $sumup['huy'] +=  $cc['huy'];                       
                $sumup['so_tb_hethong_huy'] += $cc['so_tb_hethong_huy'] ;
            
            
            }catch (\Illuminate\Database\QueryException $e) {
                }       
                
                $runtime = $tomorrowdate;
        }
        return view('backend\truyen_thong\thong_ke_truyen_thong_sms',compact('cpid','cps','articles','sumup', 'start', 'end'));

    }
    public function thong_ke_link_click()
    {
    
       if (!Auth::check()) return \Redirect::to("admincp/login");
    
    
        $stt = 1;
      
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }
        $fast = Input::get ( 'fast' );
        $link=Input::get('link');

        switch ($fast) {
            case '1':
                    break;
            case '2':
                     $start = date('Y-m-d', strtotime('-7 days'))." 00:00:00";
                     $end= date("Y-m-d")." 23:59:59";
                    break;
            case '3':
                    $start = date('Y-m-01')." 00:00:00";
                    $end= date("Y-m-d")." 23:59:59";
                    break;
            case '4':
                     $start = date('Y-m-d', strtotime('first day of previous month'))." 00:00:00";
                     $end= date("Y-m-d", strtotime('last day of previous month'))." 23:59:59";
                    break;
            case '5':
                    $start = date('Y-01-01')." 00:00:00"; 
                    $end= date("Y-m-d")." 23:59:59";
                    break;
        }             

       
        $articles = array();
        $sumup=array(0,0,0,0,0,0,0,0,0,0,0);
        $runtime = $start;
        $code = 1;
        while ($runtime<$end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
           
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));
            
            
           
            try {
            if(empty($link))
            {
                $thuebao=DB::table('temp_sub_click')
                
            ->where('created_at', '>=', $runtime)
            ->where('created_at','<=',$endofday)
            ->get();
                
            foreach ($thuebao as $key => $value) {
                if(isset($value->USER_ID))
                {
                     $cc = array("ngay"=>date('d-m-Y',strtotime($runtime)),
                            'thuebao'=>($value->USER_ID),
                            'link'=>($value->link_click),
                            'thoigian'=>date("H:i:s",strtotime($value->created_at))
                            
                            
                );

                      $articles []= $cc;  
                }
            }
        }else
        {
            $thuebao=DB::table('temp_sub_click')
                
            ->where('created_at', '>=', $runtime)
            ->where('created_at','<=',$endofday)
            ->where('link_click','like',$link."%")
            ->get();
                
            foreach ($thuebao as $key => $value) {
                if(isset($value->USER_ID))
                {
                     $cc = array("ngay"=>date('d-m-Y',strtotime($runtime)),
                            'thuebao'=>($value->USER_ID),
                            'link'=>($value->link_click),
                            'thoigian'=>date("H:i:s",strtotime($value->created_at))
                            
                            
                );

                      $articles []= $cc;  
                }
            }   
        }
            

                         
            
            } catch (\Illuminate\Database\QueryException $e) {
            }     
        
            $runtime = $tomorrowdate;

        }
        $articles = array_reverse($articles);
                         
        return view('backend.bao_cao.thong_ke_click',compact('articles'));

    }
     
}

?>