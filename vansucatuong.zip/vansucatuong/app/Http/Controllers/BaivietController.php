<?php

namespace App\Http\Controllers;
use App\Baiviet;
use App\Ctags;
use App\User;
use App\BaivietCtags;
use Datatables;
use Auth;
use DB;
use Image;

use Illuminate\Http\Request;

class BaivietController extends Controller
{

    public function index()
    {
        $cate = Ctags::where('loaictags','category')->get();
        $cpname = User::where('user_type_id',3)->get();
        $baiviet=Baiviet::select(['cms_baiviet.id as checkmark','cms_baiviet.id','tieude', 'trangthai', 'nguonbaiviet','loaibaiviet','users.name','luotxem','cms_baiviet.created_at','cms_baiviet.updated_at'])->join('users','users.id','=','cms_baiviet.userid_vietbai')->get();
        if (!Auth::check()) return \Redirect::to("admincp/login");

        return view('backend.baiviet.index',compact('cate','cpname','baiviet'));
    }

    public function create()
    {
        if (!Auth::check()) return \Redirect::to("admincp/login");
        $cate = Ctags::where('loaictags','category')->get();
        return view('backend.baiviet.add',compact('cate'));
    }

    

    public function store(Request $request)
    {
       //$update_baiviet = DB::transaction(function ($request) use ($request) 
        {

            if ($request->st_img) {
                $anhdaidien = $request->file('st_img');
                $image_name = str_random(8).'_'.$anhdaidien->getClientOriginalName();
                $anhdaidien->move('public/upload/images', $image_name);
                //$image = Image::make(sprintf('source/%s', $image_name))->resize(532, 399)->save();
            }
            
            $baiviet = new Baiviet;
            $baiviet->tieude = $request->st_tieude;

            if ($request->st_slug == '') {
                $baiviet->slug = ($request->st_tieude);
            }else{
                $baiviet->slug = $request->st_slug;
            }
            
            if ($request->st_img) { $baiviet->anhdaidien = $image_name;}
			
			
            if(isset($request->btn_save)){
				$baiviet->trangthai = 2;
			}
			
			if(isset($request->btn_sent)){
				$baiviet->trangthai = 1;
			}
			 //$baiviet->trangthai = 'hien';  
			 $baiviet->noidung = $request->st_noidung;
			 $baiviet->noidungngan = $request->st_motangan;
			 $baiviet->nguonbaiviet = $request->st_nguonbaiviet;
			 $baiviet->loaibaiviet = $request->st_dinhdang;
			 $baiviet->nhanxet = 1;
			 $baiviet->userid_vietbai = Auth::user()->id;;
			 $baiviet->userid_duyetbai=0;
			 $baiviet->luotxem = 0;
			 $baiviet->stt = 0;
			 $baiviet->userid_vietbai = Auth::user()->id;
			 $baiviet->save();

			 $theloai = $request->theloai;
			 $mediachuyenmucdel = BaivietCtags::where('idbaiviet',$baiviet->id);
			 $mediachuyenmucdel->delete();

			 if (isset($theloai) && count($theloai) > 0) {
				foreach ($theloai as $key => $value) {
					$baivietctags = new BaivietCtags;
					$baivietctags->idbaiviet = $baiviet->id;
					$baivietctags->idctags = $value;
					$baivietctags->save();
				}
			}
			return redirect('admincp/baiviet/taobaiviet')->with('thongbao','Tạo thành công!');
		}
        //);
        return $update_baiviet;
    }

    

    public function edit($id)
    {
        if (!Auth::check()) return \Redirect::to("admincp/login");
        $baiviet = Baiviet::find($id);
        $cate = Ctags::where('loaictags','category')->get();
        $listcat = BaivietCtags::where('idbaiviet',$id)->get()->toArray();
        foreach($listcat as $arr_idchuyenmuc)
        {
            $listcat[] = $arr_idchuyenmuc['idctags'];
        }
        return view('backend.baiviet.edit',compact('baiviet','cate','listcat'));
    }

    public function update(Request $request)
    {
		
        //$update_baiviet = DB::transaction(function ($request) use ($request) 
        {
            $baiviet = Baiviet::find($request->st_editid);
            $baiviet->tieude = $request->st_tieude;

            if ($request->st_slug == '') {
                $baiviet->slug = ($request->st_tieude);
            }else{
                $baiviet->slug = $request->st_slug;
            }
			
			// if(isset($request->btn_xoa)){
				// $baiviet->trangthai = 1;
			// }
			
			if(isset($request->btn_update)){
				$baiviet->trangthai = 1;
			}
			
			if(isset($request->btn_save)){
				$baiviet->trangthai = 2;
			}
			
			// if(isset($request->btn_duyet)){
				// $baiviet->trangthai = 1;
				// $baiviet->userid_duyetbai=Auth::user()->id;
			// }

			 $anhdaidien = $request->file('st_img');
              if ($anhdaidien) {
                $image_name = str_random(8).'_'.$anhdaidien->getClientOriginalName();
                $anhdaidien->move('public/upload/images', $image_name);
                //$image = Image::make(sprintf('source/%s', $image_name))->resize(532, 399)->save();
                $baiviet->anhdaidien = $image_name;
              }   
			 // if ($anhdaidien) {
				// $image_name = str_random(8).'_'.$anhdaidien->getClientOriginalName();
				// $anhdaidien->move('public/source/', $image_name);
				// $baiviet->anhdaidien = $image_name;
			 // }
        
        $baiviet->noidung = $request->st_noidung;
        $baiviet->noidungngan = $request->st_motangan;
        $baiviet->nguonbaiviet = $request->st_nguonbaiviet;
        $baiviet->loaibaiviet = $request->st_dinhdang;
        $baiviet->nhanxet = 1;
        //$baiviet->userid_vietbai = 0;
        $baiviet->luotxem = 0;
        $baiviet->stt = 0;
        $baiviet->save();

        $theloai = $request->theloai;
        $mediachuyenmucdel = BaivietCtags::where('idbaiviet',$request->st_editid);
        $mediachuyenmucdel->delete();

        if (isset($theloai) && count($theloai) > 0) {
            foreach ($theloai as $key => $value) {
                $baivietctags = new BaivietCtags;
                $baivietctags->idbaiviet = $request->st_editid;
                $baivietctags->idctags = $value;
                $baivietctags->save();
            }
        }

        return redirect('admincp/baiviet/sua/'.$request->st_editid)->with('thongbao','Lưu lại thành công!');
    }
//);
        return $update_baiviet;
    }

   

    public function duyetbai(Request $request)
    {
        //return $request->check;
        foreach ($request->check as $key => $value) {
            $baiviet = Baiviet::find($value);
            $baiviet->trangthai = 3;
            $baiviet->save();
        }
        return \Redirect::to('admincp/baiviet/danhsach');
    }
	
	public function xoabai(Request $request){
        
		foreach ($request->check as $key => $value) {
            $baiviet = Baiviet::destroy($value);
            //$baiviet->delete();
        }

		return "true";	}

    
}
