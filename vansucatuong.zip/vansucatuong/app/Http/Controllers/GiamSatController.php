<?php

use App\Http\Requests;
use App\Post;
namespace App\Http\Controllers;


use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use PhpParser\Comment;
use Illuminate\Cookie\CookieJar;
use Datatables;
use App\UserTypes;
use Illuminate\Support\Facades\Auth;

class GiamSatController extends Controller
{

    public function giamsat_sms(){
    	if (!Auth::check()) return \Redirect::to("login");

      $u = UserTypes::find(Auth::user()->user_type_id);
      $up = explode(',',$u->permissions);
     

   return view('backend.giamsat.giamsat_sms');
}

public function getData_giamsat_sms(Request $request)
{
    if (!Auth::check()) return \Redirect::to("login");
    
    $u = UserTypes::find(Auth::user()->user_type_id);
    $up = explode(',',$u->permissions);
    
   $start = date('Y-m-d')." 00:00:00";
   $end = date('Y-m-d')." 23:59:59";
   $year = date('Y');
   $month = date('m');
   $tablen = 'logcharging'.$year.$month;

   $query = DB::table($tablen)->select(['TIME_REQUEST', 'REASON', 'SUBID', 'info', 'ERROR_DESC'])
   ->where('REASON', '!=', 'RENEW')
   ->where('TIME_REQUEST', '>=', $start)
   ->where('TIME_REQUEST', '<=', $end)
   ->orderBy('TIME_REQUEST', 'desc');
   $datatables = app('datatables')->of($query)

   ->editColumn('TIME_REQUEST', '{!!$REASON == "REG" ? "<h1 style=\"font-size: 100%;\" class=\"label label-success\">$TIME_REQUEST</h1>": "<h1 style=\"font-size: 100%;\" class=\"label label-primary\">$TIME_REQUEST</h1>"!!}')

   ->editColumn('REASON', '{!!$REASON == "REG" ? "<h1 style=\"font-size: 100%;\" class=\"label label-success\">Đăng ký</h1>": "<h1 style=\"font-size: 100%;\" class=\"label label-primary\">Hủy</h1>"!!}')
   ->editColumn('SUBID', '{{$SUBID}}')
   ->editColumn('info', '{{$info}}')
   ->editColumn('ERROR_DESC', '{!!$ERROR_DESC == "Successful" ? "<h1 style=\"font-size: 100%;\" class=\"label label-success\">Thành công</h1>": "<h1 style=\"font-size: 100%;\" class=\"label label-primary\">Không thành công</h1>"!!}');

   if ($loai_giaodich = $datatables->request->get('trangthai')) {
    if ($loai_giaodich == '0') {  

    }elseif($loai_giaodich == '1'){
        $datatables->where('REASON', 'REG');
    }elseif($loai_giaodich == '2'){
        $datatables->where('REASON', 'UNREG');
    }   
}
;return $datatables->make();
}

public function giamsat_charging(){
    if (!Auth::check()) return \Redirect::to("login");
    
    $u = UserTypes::find(Auth::user()->user_type_id);
    $up = explode(',',$u->permissions);
   

   return view('backend.giamsat.giamsat_charging');
}

public function getData_giamsat_charging(Request $request)
{
    if (!Auth::check()) return \Redirect::to("login");
    
    $u = UserTypes::find(Auth::user()->user_type_id);
    $up = explode(',',$u->permissions);
   
   
    if($time_bat_dau = $request->time_bat_dau) {
        if ($time_ket_thuc = $request->time_ket_thuc) {
            $start = $time_bat_dau." 00:00:00";   
            $end = $time_ket_thuc." 23:59:59"; 
            $year = date('Y',   strtotime($time_bat_dau)); 
            $month = date('m',  strtotime($time_bat_dau));
        }
    }
    
   $tablen = 'logcharging'.$year.$month;

   $query = DB::table($tablen)->select(['ERROR_DESC', \DB::raw('count(ERROR_DESC) as c')])
   ->where('REASON', 'RENEW')
   ->where('TIME_REQUEST', '>=', $start)
   ->where('TIME_REQUEST', '<=', $end)
   ->groupBy('ERROR_DESC');
   $datatables = app('datatables')->of($query)
   ->editColumn('ERROR_DESC', '{!!$ERROR_DESC == "Successful" ? "<h1 style=\"font-size: 100%;\" class=\"label label-success\">Thành công</h1>": "<h1 style=\"font-size: 100%;\" class=\"label label-primary\">$ERROR_DESC </h1>"!!}')
   // ->addColumn('action', function ($query) {
   //          $hung = $request->time_bat_dau;
   //          return $hung;
   //      })
   ;
;return $datatables->make();
}

}