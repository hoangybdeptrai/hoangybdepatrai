<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;
use App\MTPush;
use App\MTActive;
use App\Customer;
use App\CustomerDone;
use App\Parameter;
use App\CustomerNTX;
use App\Test;
use App\CustomerPushMT;
use Datatables;
//use DB;
use Active;
use App\UserType;
use PhpParser\Comment;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class MTPushBaoCaoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (!Auth::check()) return \Redirect::to("login");
        // $u = UserType::find(Auth::user()->user_type_id);
        // $up = explode(',',$u->permissions);
        // if (!in_array('danh_sach_thue_bao_gui',$up)) return \Redirect::to("/");

        $a = 1;
        $b = 0;
        $da_gui = Customer::where('SENDER','LIKE','%'.$a.'%')->get();
        $chua_gui = Customer::where('SENDER','LIKE','%'.$b.'%')->get();
       
        return view('backend.push_mt.baocao.index', compact('da_gui', 'chua_gui'));
    }

    public function getData()
    {
        
        $mt_do2 = Customer::select(['id', 'USER_ID', 'SENDER', 'MT_ID', 'REQUEST_ID']);
        return Datatables::of($mt_do2)

        ->editColumn('id', '#{{$id}}')
        ->editColumn('USER_ID', '{{$USER_ID}}')
        ->editColumn('SENDER', '{{$SENDER}}')
        ->editColumn('MT_ID', '{{$MT_ID}}')
        ->editColumn('REQUEST_ID', '{{$REQUEST_ID}}')
      

       
         
            ->addColumn('action', function ($mt_do2) {
                return '

                        <a onclick="redirect_edit_url(' . "'" . $mt_do2->id . "'" . ')" href="javascript:void(0)" class="btn btn-xs btn-primary" id="edit"><i class="glyphicon glyphicon-edit"></i> Sửa</a>

                        <a onclick="remove_customer(' . "'" . $mt_do2->id . "'" . ')" href="javascript:void(0)" class="btn btn-xs btn-danger"><i class="fa fa-trash-o"></i> Xóa</a> ';
            })

            ->make();   

           
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.push_mt.baocao.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $mt_do2 = new Customer;
        $mt_do2->USER_ID = \Request::get('USER_ID');
        /*$mt_do2->SENDER = \Request::get('SENDER');
        $mt_do2->MT_ID = \Request::get('MT_ID');
        $mt_do2->REQUEST_ID = \Request::get('REQUEST_ID');*/
        $mt_do2->save();
/*
        $mtactive = new MTActive;
        
        $mtactive->Type = \Request::get('ACTIVE');*/

        return \Redirect::to('admincp/customer');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $mt_do2 = Customer::find($id);
        return view('backend.push_mt.baocao.sua', compact('mt_do2'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $mt_do2 = Customer::find($id);
        $mt_do2->USER_ID = \Request::get('USER_ID');
        /*$mt_do2->SENDER = \Request::get('SENDER');
        $mt_do2->MT_ID = \Request::get('MT_ID');
        $mt_do2->REQUEST_ID = \Request::get('REQUEST_ID');*/
        $mt_do2->save();
        return \Redirect::to('admincp/customer');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $mt_do2 = Customer::find($id);
        $mt_do2->delete();
        return \Redirect::to('admincp/customer');
    }

    public function delete()
    {
        Customer::truncate();
        return \Redirect::to('admincp/mt/read');
    }

    public function bao_cao_kq()
    {
 
        $thongke = DB::table('reportday')->get();
        $articles = array(0,0,0,0,0);
        $dk = 0;
        //$MT=DB::table('mtsample')->get();   
        $mangrep=[];   
        //$rep= str_replace("Aha: Mt so ","",$thongke[0]->Report);
      // return $mangrep=explode("_",$rep);
      $i=0;
      foreach ($thongke as $key => $value) {
             $rep= str_replace("Aha: Mt so ","",$value->Report);
         $mangrep[]=explode("_",$rep);
         //if()
       //print_r( $mangrep[$i][1]);
       
        {
            $idmt=$mangrep[$i][0];
            $MT=DB::table('mtsample')->where('Id_Mt',$idmt)->get();
            foreach ($MT as $key => $value1) {
                $ndmt=$value1->Content;
            }
            if(isset( $mangrep[$i][1]))
            {
                $cc=array("date"=>str_replace("00:00:00","",$value->Day),
                    "MT_id"=>$idmt,
                    "ndmt"=>$ndmt,
                    "sothuebaogui"=>$mangrep[$i][1],
                    'sothuebaodangky'=>$mangrep[$i][2],
            );
            //print_r( $cc);
            $article[]=$cc;
            }
          
            
        }
            
          
          $i++;
      }
        

        return view('backend.push_mt.baocao.bao_cao',  compact('article'));
    }
    function pa($a){
        if (!isset($a)) return 0; 
            else if (!$a) return 0;else return $a;
    }
    public function tim_kiem_qc()
    {
        if (!Auth::check()) return \Redirect::to("admincp/login");
        
        if (empty(Input::get ( 'time_bat_dau' ))|| empty(Input::get ( 'time_ket_thuc' ))) {
            $end= date("Y-m-d")." 23:59:59";
            if (empty(Input::get ( 'time_bat_dau' )))
              $start = date('Y-m-d')." 00:00:00";
            else
              $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00");              
        } else {
            $start = str_replace("/","-",Input::get ( 'time_bat_dau' )." 00:00:00"); 
            $end = str_replace("/","-",Input::get ( 'time_ket_thuc' )." 23:59:59");
        }


        $stt = 1;
        $mt_id = MTDo::all();

        $articles = array();
        $runtime = $start;
        while ($runtime < $end) {
            $tomorrow = strtotime("tomorrow", strtotime($runtime));
            $tomorrowdate = date('Y-m-d H:i:s',$tomorrow);
            $endofday = date('Y-m-d H:i:s',$tomorrow-1);
            //echo "$runtime $endofday <br/>";
            $month = (date("m",strtotime($runtime)));
            $year = (date('Y', strtotime($runtime)));


               



try {
    $thongke = DB::table('reportday')
    ->where('Day', '>=', $runtime)->where('Day', '<=', $endofday)
    ->get();
        $articles = array(0,0,0,0,0);
        $dk = 0;
        //$MT=DB::table('mtsample')->get();   
        $mangrep=[];   
        //$rep= str_replace("Aha: Mt so ","",$thongke[0]->Report);
      // return $mangrep=explode("_",$rep);
      $i=0;
      foreach ($thongke as $key => $value) {
             $rep= str_replace("Aha: Mt so ","",$value->Report);
         $mangrep[]=explode("_",$rep);
         //if()
       //print_r( $mangrep[$i][1]);
       
        {
            $idmt=$mangrep[$i][0];
            $MT=DB::table('mtsample')->where('Id_Mt',$idmt)->get();
            foreach ($MT as $key => $value1) {
                $ndmt=$value1->Content;
            }
            if(isset( $mangrep[$i][1]))
            {
                $cc=array("date"=>str_replace("00:00:00","",$value->Day),
                    "MT_id"=>$idmt,
                    "ndmt"=>$ndmt,
                    "sothuebaogui"=>$mangrep[$i][1],
                    'sothuebaodangky'=>$mangrep[$i][2],
            );
            //print_r( $cc);
            $article[]=$cc;
            }
          
            
        }
           
          
          $i++;
        
   }              
    } catch (\Illuminate\Database\QueryException $e) {
            }       
               
                 $runtime = $tomorrowdate;
                 



        }

        $articles = array_reverse($articles);
        $thongke_hangngay = DB::table('thong_ke_hang_ngay')->orderBy('created_at', 'desc')->get();
        $thongke_doanhthu = DB::table('thong_ke_doanh_thu')->orderBy('created_at', 'desc')->get();
        $dk = 0;
        $huy = 0;
        $dk_mt = 0;
        $huy_mt = 0;
        $mt = '';
        $doanhthu = 0;
        $doanhthu_mt = 0;
        foreach ($thongke_hangngay as $key => $value) {
            $dk+= $value->tong_so_dang_ki;
            $huy+= $value->tong_so_huy;
            $dk_mt+= $value->tong_so_dang_ki_data;
            $huy_mt+= $value->tong_so_huy_data;
            $mt+= $value->tong_mt_ban_trong_ngay;
        }
        foreach ($thongke_doanhthu as $key => $value) {
            $doanhthu+=$value->tong_doanh_thu;
            $doanhthu_mt+=$value->doanh_thu_push_mt;
        }

        
          
        return view('backend.push_mt.baocao.bao_cao', compact('articles', 'stt', 'sum', 'dangky', 'mt_id', 'start', 'end', 'article', 'thongke_hangngay', 'thongke_doanhthu', 'dk', 'huy', 'dk_mt', 'huy_mt', 'mt', 'doanhthu', 'doanhthu_mt'));
          
    }

    // public function read2(Request $request)
    // {
    //     set_time_limit(0);
        
    //     $number = Input::get ( 'soluong' );
        
    //     //echo $result.'<br/>';
        
    //     //$result = CustomerNTX::orderBy(DB::raw('RAND()'))->select('USER_ID')->take(10)->get();
    //             //echo $value.'<br/>';
    //             //
    //     for($i=1; $i<=$number;$i++){
    //         //$result = CustomerNTX::all('USER_ID')->random(1);
    //         $result = CustomerNTX::orderBy(DB::raw('RAND()'))->select('USER_ID')->where('STATUS', 2)->orwhere('STATUS', 0)->take(1)->value('USER_ID');
            
    //         //echo $result.'<br/>';
    //         $user = Test::where('USER_ID', $result )->first();
    //         $user1 = Customer::where('USER_ID', $result )->first();
    //             if (!$user && !$user1) {

    //             $cus = new Customer;
    //             $cus->USER_ID = $result;
    //             $cus->save();
    //             //echo $cus.'<br/>';
    //             }
    //         }
                
         
    //     return \Redirect::to('admincp/mt/read')->withErrors(['Chọn Thành Công', 'The Message']);
        
    // }

    public function lichsutacdong(){

        $user = DB::table('users')->get();
       
        return view('backend.push_mt.baocao.lichsutacdong', compact('user'));

    }

    public function tim_lichsutacdong(Request $request){
        $user = DB::table('users')->get();
        $tk = $request->input('user');

        if($tk == '0')
        $taikhoan = DB::table('lich_su_tac_dong')->orderBy('created_at', 'desc')->get();  
        else
        $taikhoan = DB::table('lich_su_tac_dong')->where('email', $tk)->orderBy('created_at', 'desc')->get();
        
        
        
        return view('backend.push_mt.baocao.lichsutacdong', compact('taikhoan', 'user'));
        
        
    }

}
