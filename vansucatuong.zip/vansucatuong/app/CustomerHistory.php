<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerHistory extends Model
{
    protected $table = 'customer_history';
    protected $fillable = [
        'USER_ID'
    ];
    //protected $primaryKey = 'USER_ID';
    public $incrementing = false; // Bỏ lỗi hiển thị cùng giá trị MSISDN
}
