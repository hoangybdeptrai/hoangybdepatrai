<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ctags extends Model
{
    protected $table = 'cms_ctags';
}
