<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoiCuoc extends Model
{
    protected $table = 'service_package';
}
