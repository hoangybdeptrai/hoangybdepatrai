<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cpname extends Model
{
    protected $table = 'cpname';
	 protected $primaryKey = 'id';
}
