<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LogvasReq extends Model
{
    protected $table = 'log_vas_request';
}
